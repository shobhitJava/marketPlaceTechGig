package org.hyperledger.fabric.jio;

import static java.lang.String.format;
import static java.nio.charset.StandardCharsets.UTF_8;
import static org.hyperledger.fabric.sdk.Channel.DiscoveryOptions.createDiscoveryOptions;
import static org.hyperledger.fabric.sdk.Channel.PeerOptions.createPeerOptions;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hyperledger.fabric.protos.peer.Query.ChaincodeInfo;
import org.hyperledger.fabric.sdk.BlockEvent;
import org.hyperledger.fabric.sdk.ChaincodeCollectionConfiguration;
import org.hyperledger.fabric.sdk.ChaincodeEndorsementPolicy;
import org.hyperledger.fabric.sdk.ChaincodeEvent;
import org.hyperledger.fabric.sdk.ChaincodeEventListener;
import org.hyperledger.fabric.sdk.ChaincodeID;
import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.EndorsementSelector;
import org.hyperledger.fabric.sdk.HFClient;
import org.hyperledger.fabric.sdk.InstallProposalRequest;
import org.hyperledger.fabric.sdk.InstantiateProposalRequest;
import org.hyperledger.fabric.sdk.Orderer;
import org.hyperledger.fabric.sdk.Peer;
import org.hyperledger.fabric.sdk.ProposalResponse;
import org.hyperledger.fabric.sdk.QueryByChaincodeRequest;
import org.hyperledger.fabric.sdk.TransactionProposalRequest;
import org.hyperledger.fabric.sdk.TransactionRequest.Type;
import org.hyperledger.fabric.sdk.UpgradeProposalRequest;
import org.hyperledger.fabric.sdk.Channel.PeerOptions;
import org.hyperledger.fabric.sdk.Peer.PeerRole;
import org.hyperledger.fabric.sdk.exception.ChaincodeCollectionConfigurationException;
import org.hyperledger.fabric.sdk.exception.ChaincodeEndorsementPolicyParseException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.exception.ServiceDiscoveryException;
import org.hyperledger.fabric.sdk.exception.TransactionEventException;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.hyperledger.fabric.sdk.testutils.TestConfig;
import org.hyperledger.fabric.sdkintegration.Util;

public class SDKClientDocPairChannelMP {

	private static final String CHANNEL_NAME = "pairchannel";
	static HFClient hfclient = null;
	private static final String EXPECTED_EVENT_NAME = "event";
	private static final String USER_NAME = "admin";
	private static final String USER_MSP_ID = "doctorsMSP";
	//private static final String USER_MSP_ID = "UserMSP";
	
	private static final String CHAIN_CODE_FILEPATH = "sdkintegration/gocc/sample1";
	private static final String CHAIN_CODE_NAME = "mpp6";
	private static final String CHAIN_CODE_PATH = "github.com/gov";
	private static final String CHAIN_CODE_VERSION = "1";
	private static final String TEST_FIXTURES_PATH = "src/test/fixture";
	private static final String NODE_CHAIN_CODE_FILEPATH = "sdkintegration/nodecc/sample1";
	private static final String NODE_CHAIN_CODE_NAME = "mychaincodeNode3";
	private static final String NODE_CHAIN_CODE_PATH = ".";
	private static final String NODE_CHAIN_CODE_VERSION = "1.1";
	private static final String NODE_TEST_FIXTURES_PATH = "src/test/fixture";
	//private static final String PEER1_ADDRESS = "grpc://10.64.217.120:7051";
	//private static final String ORDERER1_ADDRESS = "grpc://10.64.217.120:7050";
	//private static final String PEER1_ADDRESS = "grpc://10.64.217.120:7051";
/*	private static final String PEER1_ADDRESS = "grpc://10.64.217.120:7059";
	
	private static final String PEER1_NAME = "peer0.docs.test";
	//private static final String PEER1_NAME = "peer0.user.mnp1.com";
private static final String PEER2_ADDRESS = "grpc://10.64.217.120:7060";
	
	private static final String PEER2_NAME = "peer0.government.test";*/
	
	private static final String PEER2_ADDRESS = "grpc://10.64.217.120:7059";
	
	private static final String PEER2_NAME = "peer0.docs.test";
	private static final String PEER1_ADDRESS = "grpc://10.64.217.120:7060";
	private static final String PEER1_NAME = "peer0.government.test";
	
	private static final String PEER3_ADDRESS = "grpc://10.64.217.120:7062";
	private static final String PEER3_NAME = "peer0.firm2.test";
	
	//private static final String PEER2_ADDRESS = "grpc://10.64.217.120:7061";
	//private static final String PEER3_ADDRESS = "grpc://10.64.253.213:9051";
	private static final String PEER4_ADDRESS = "grpc://10.64.253.213:10051";
	//private static final String PEER2_NAME = "peer0.operator.mnp1.com";

	private static final String PEER4_NAME = "peer1.org2.example.com";
	private static final String ORDERER1_NAME = "orderer.mp.test";
	//private static final String ORDERER1_NAME = "orderer.mnp1.com";
	private static final String ORDERER1_ADDRESS = "grpc://10.64.217.120:7050";
	private static final String keystoreLocation =  "C:\\BlockchainCerti\\120\\mp\\medical.test\\users\\Admin@medical.test\\msp\\keystore";
	private static final String usercertfile = "C:\\BlockchainCerti\\120\\mp\\medical.test\\users\\Admin@medical.test\\msp\\signcerts\\Admin@medical.test-cert.pem";
	private static final String orgName = "medical.test";
	//private static final String orgName = "org1.example.com";
	
	static Executor executor = Executors.newCachedThreadPool(); 
	
	static class Generator implements Runnable {

		String[] args;

		Channel testChannel;

		public Generator(Channel testChannel, String[] args) {
			// TODO Auto-generated constructor stub
			this.testChannel = testChannel;
			this.args = args;
		}

		@Override
		public void run() {
			TransactionProposalRequest transactionProposalRequest = hfclient.newTransactionProposalRequest();
			transactionProposalRequest.setFcn("recordUPCgeneration");
		
		//transactionProposalRequest.setFcn("getReportForOperator");
		//transactionProposalRequest.setFcn("getReportForNumber");
			ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).setVersion(CHAIN_CODE_VERSION).build();

			transactionProposalRequest.setChaincodeID(chaincodeID);

			transactionProposalRequest.setArgs(args);
			// transactionProposalRequest.setArgs("CAR11", "Chevy1", "Volt1",
			

			

		}
	}
	public static void main(String[] args) {
		
		 /*class ChaincodeEventCapture implements ChaincodeEventListener { //A test class to capture chaincode events
	            final String handle;
	            final BlockEvent blockEvent;
	            final ChaincodeEvent chaincodeEvent;

	            ChaincodeEventCapture(String handle, BlockEvent blockEvent, ChaincodeEvent chaincodeEvent) {
	                this.handle = handle;
	                this.blockEvent = blockEvent;
	                this.chaincodeEvent = chaincodeEvent;
	            }

				@Override
				public void received(String handle, BlockEvent blockEvent, ChaincodeEvent chaincodeEvent) {
					System.out.println(handle);
				
					
				}
	        }*/
		try {
			System.out.println("initialize logger");
			Logger logger = Logger.getLogger(SDKClientDocPairChannelMP.class);
			logger.setLevel(Level.ERROR);
			System.out.println("creating hf client");
			int i =0;File sampleStoreFile = new File(System.getProperty("user.home") + "/test.properties");

			if (sampleStoreFile.exists()) { // For testing start fresh
				sampleStoreFile.delete();
			}
			logger.info("creating store object");
			final SDKStore sdkStore = new SDKStore(sampleStoreFile);


			logger.info("creating sdk user object");
			SDKUser someTestUSER = sdkStore.getMember(USER_NAME, orgName, USER_MSP_ID,
					findFileSk(keystoreLocation), new File(usercertfile));
			
			someTestUSER.setMspId(USER_MSP_ID);
		
				//TimeUnit.MILLISECONDS.sleep(100);
			File tempFile = File.createTempFile("teststore", "properties");

			tempFile.deleteOnExit();
		
			
			hfclient = HFClient.createNewInstance();
		
			

			hfclient.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());
			hfclient.setUserContext(someTestUSER);
			
			logger.info("creating sdk user object");
			
			Channel testChannel = hfclient.newChannel(CHANNEL_NAME);
			// Channel testChannel = hfclient.getChannel(CHANNEL_NAME);
			System.out.println("joining channel");

			Peer peer1 = hfclient.newPeer(PEER1_NAME, PEER1_ADDRESS);
			Peer peer2 = hfclient.newPeer(PEER2_NAME, PEER2_ADDRESS);
			Peer peer3 = hfclient.newPeer(PEER3_NAME, PEER3_ADDRESS);
			//Peer peer4 = hfclient.newPeer(PEER4_NAME, PEER4_ADDRESS);
			Orderer orderer = hfclient.newOrderer(ORDERER1_NAME, ORDERER1_ADDRESS);
			System.out.println("adding peer "+PEER1_NAME);
		//	testChannel.addPeer(peer1);

			testChannel.addPeer(peer2);
		//	testChannel.addPeer(peer3);
			//testChannel.addPeer(peer4);
			System.out.println("adding orderer "+ORDERER1_NAME);
			testChannel.addOrderer(orderer);
	

			//PeerOptions pos = createPeerOptions().setPeerRoles(EnumSet.of(PeerRole.SERVICE_DISCOVERY, PeerRole.LEDGER_QUERY, PeerRole.EVENT_SOURCE, PeerRole.CHAINCODE_QUERY));
			
			/*Properties sdprops = new Properties();
		    
			 sdprops.put("org.hyperledger.fabric.sdk.discovery.default.protocol", "grpc:");
			 System.setProperty("org.hyperledger.fabric.sdk.test.endpoint_remap_discovery_host_name", "10.64.217.120");
			 sdprops.put("org.hyperledger.fabric.sdk.test.endpoint_remap_discovery_host_name", "10.64.217.120");
			 System.setProperty("org.hyperledger.fabric.sdk.test.endpoint_remap_discovery_host_name", "10.64.217.120");*/ 
			
			//	Peer peer2 = hfclient.newPeer(PEER1_NAME, PEER1_ADDRESS, sdprops);
			//	 testChannel.addPeer(peer2, pos);
			
			testChannel.initialize();
			logger.info("Channel intialized successfully");
		
	
		//	List<ChaincodeInfo> installedChaincodeInfos = hfclient.queryInstalledChaincodes( testChannel.getPeers().iterator().next());
		createChainCodeGo(testChannel);
		instantiateChaincode(testChannel);
	//		upgradeChaincode(testChannel);
//Thread.sleep(2000);
		//	"contract": "{\"contract\":{\"id\":\"1\",\"conditions\":\"\"}}"
			
			//client.instantiateChaincode( chainCodeDetail, "commonchannel");

			String po ="{\"commodity\":\"Oil\",\"date\":\"2019-03-22T18:30:00.000Z\",\"currency\":\"Dollar\",\"iname\":\"Tata\",\"ename\":\"Reliance\",\"quantity\":\"12\",\"price\":\"890\",\"amount\":\"10680\"}";	
			
			/*String json = "{\"doName\":\"jio\",\"mnpConnectAck\":\"1526983743151\",\"mnpDisconnectAck\":\"1526983728936\",\"mnpDisconnectReq\":\"1526983714789\",\"mnpGenerated\":\"1526983617008\",\"mnpKYC\":\"1526983684261\",\"mnpPortOut\":\"1526983714789\",\"mnpStatus\":\"Connect_Completed\",\"mnpCompleted\":\"1526988449336\",\"mnpValidated\":\"1526983656080\",\"mobile_no\":\""+i+"\",\"roName\":\"Jio\"}";
			String json2 = "{\"Customer_Segment\":\"Prepaid\",\"eKYC_Status\":\"Pending\",\"Contractual_Obligation\":\"No\",\"Corporate_connection\":\"No\",\"Network_Ageing\":\"27\",\"Under Processing\":\"No\",\"Payments_Due\":\"0\",\"Sub_judice\":\"No\",\"Prohibited\":\"No\",\"LEA_flag\":\"No\",\"Aadhar_Number\":\"valid UIDAI\"}";
			
				String json1 = "{\"breed\":\"jersey\",\"weight\":\"78kg\",\"farmerId\":\"56565662\"}";
		*/		
			String json1 = "{\"weight\":\"89\",\"color\":\"grey\",\"breed\":\"jersey\",\"status\":\"Verified\",\"healthRecord\":[{\"checkUpTime\":\"1554635703\",\"healthCeritificate\":\"pic1\",\"doctorId\":\"doc1\"}]}";
			String cow = "{\"pic\":\"jjkljklnmbjabjkqsdhkjq12k\",\"state\":\"xyz\",\"district\":\"xyz\",\"tehsil\":\"xyz\",\"farmerId\":\"56565663\",\"dob\":\"1273230903\",\"isCalfProduced\":\"false\",\"parentId\":\"null\"}";
			String status  = "{\"status\":\"VERIFIED\"}";
			String demp = "{\"amount\":\"9000\",\"bidId\":\"bid2\",\"cowId\":\"COW1\",\"farmerId\":\"56565662\",\"type\":\"bid\"}";
			
			
			//genUPCC(testChannel,"deleteCow",new String[]{"COW1"});
			
			
			
String json2 = "{\"weight\":\"89kg\",\"color\":\"grey\",\"breed\":\"jersey\",\"status\":\"Verified\",\"healthRecord\":{\"checkUpTime\":\"1557921753\",\"healthCeritificate\":\"pic1\",\"doctorId\":\"doc1\"}}";
			//genUPCC(testChannel,"appendDocument",new String[]{"COW1",status});
			//genUPCC(testChannel,"updateCowHealth",new String[]{"COW1",json2});
	//genUPCC(testChannel,"updateCowHealth",new String[]{"COW1",json1});
	/*	genUPCC(testChannel,"createEntity",new String[]{cow});
		Thread.sleep(2000);
		genUPCC(testChannel,"updateCowHealth",new String[]{"COW1",json1});*/
		//Thread.sleep(2000);
		//genUPCC(testChannel,"markCowOnSale",new String[]{"COW1"});
		//Thread.sleep(2000);
		//genUPCC(testChannel,"acceptBid",new String[]{demp});//createEntity markCowOnSale bidForCow appendDocument
		
		//Thread.sleep(2000);
			String a[]={"breed","jersey","tehsil","abc","0","15"};
			String b[]={"breed","jersey","tehsil","abc","0","15"};
			String c[]={"olroad","Noida"};
			//query(c,testChannel,"getAllCowsData" );
			
				//System.out.println(i++);
			
		
		
		}catch (Exception e) {
			System.out.println(e);
		}
	}

	
	
	public static void query(String []args, Channel channel, String functionName)
			throws InvalidArgumentException, ProposalException {
		String payload = null;
		
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).setVersion(CHAIN_CODE_VERSION).build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setFcn(functionName);
		queryByChaincodeRequest.setArgs(args);
		Map<String, byte[]> tm2 = new HashMap<>();
		tm2.put("HyperLedgerFabric", "QueryByChaincodeRequest:JavaSDK".getBytes(UTF_8));
		tm2.put("method", functionName.getBytes(UTF_8));
		queryByChaincodeRequest.setTransientMap(tm2);

		Collection<ProposalResponse> queryProposals = channel.queryByChaincode(queryByChaincodeRequest);
		for (ProposalResponse proposalResponse2 : queryProposals) {
			if (!proposalResponse2.isVerified()
					|| proposalResponse2.getStatus() != ProposalResponse.Status.SUCCESS) {
			
			} else {
			System.out.println(proposalResponse2.getProposalResponse().getResponse().getPayload().toStringUtf8());
				
			}
		}

	}

	private static QueryByChaincodeRequest queryMychaincode() {
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setArgs("B");
		queryByChaincodeRequest.setFcn("query");
		return queryByChaincodeRequest;

	}

	public static void createChainCodeGo (Channel testChannel)
			throws InvalidArgumentException, ProposalException, IOException {
		InstallProposalRequest installProposalRequest = hfclient.newInstallProposalRequest();

		installProposalRequest.setChaincodeLanguage(Type.GO_LANG);
		installProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);

		
		installProposalRequest.setChaincodeName(CHAIN_CODE_NAME);

		
		installProposalRequest.setChaincodePath("github.com/gov");
	
		installProposalRequest.setChaincodeInputStream(Util.generateTarGzInputStream(
				(Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src", CHAIN_CODE_PATH).toFile()),
				Paths.get("src", CHAIN_CODE_PATH).toString()));
		
		Collection<ProposalResponse> proposalResponse = testChannel.sendInstallProposal(installProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}
	}

	public static QueryByChaincodeRequest queryNodeChaincode(Channel testChannel) {
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(NODE_CHAIN_CODE_NAME).build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setArgs("B");
		queryByChaincodeRequest.setFcn("query");
		return queryByChaincodeRequest;
	}

	public static void createChainCodeNode(Channel testChannel)
			throws InvalidArgumentException, ProposalException, IOException {
		InstallProposalRequest installProposalRequest = hfclient.newInstallProposalRequest();

		installProposalRequest.setChaincodeLanguage(Type.NODE);
		installProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
		installProposalRequest.setChaincodeName(NODE_CHAIN_CODE_NAME);

		
		File file = new File("src/test/fixture/sdkintegration/gocc/sample1");
		System.out.println("file exists " + file.exists());
		System.out.println(Paths.get(NODE_TEST_FIXTURES_PATH, NODE_CHAIN_CODE_FILEPATH, "src", NODE_CHAIN_CODE_PATH));

		// installProposalRequest.setChaincodeSourceLocation(file);
		
		  
		installProposalRequest.setChaincodeInputStream(
				Util.generateTarGzInputStream((Paths.get(NODE_TEST_FIXTURES_PATH, NODE_CHAIN_CODE_FILEPATH).toFile()),
						Paths.get("src", NODE_CHAIN_CODE_PATH).toString()));
		
		Collection<ProposalResponse> proposalResponse = testChannel.sendInstallProposal(installProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}
	}

	public static void createChainCodeJava(Channel testChannel)
			throws InvalidArgumentException, ProposalException, IOException {
		InstallProposalRequest installProposalRequest = hfclient.newInstallProposalRequest();

		installProposalRequest.setChaincodeLanguage(Type.JAVA);
		installProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);

		installProposalRequest.setChaincodeName(CHAIN_CODE_NAME);

	
		File file = new File("/src/org/hyperledger/fabric/sdk/ChainCodeImpl.java");
		System.out.println("file exists " + file.exists());
		System.out.println(Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src", CHAIN_CODE_PATH));

		installProposalRequest.setChaincodeInputStream(
				Util.generateTarGzInputStream((Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH).toFile()), "src"));
	
		
		 
		installProposalRequest.setChaincodePath(null);
		Collection<ProposalResponse> proposalResponse = testChannel.sendInstallProposal(installProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}
	}

	public static void instantiateChaincode(Channel testChannel)
			throws InvalidArgumentException, ProposalException, ChaincodeEndorsementPolicyParseException, IOException,
			InterruptedException, ExecutionException, TimeoutException, ChaincodeCollectionConfigurationException {
			InstantiateProposalRequest instantiateProposalRequest = hfclient.newInstantiationProposalRequest();
		instantiateProposalRequest.setChaincodeName(CHAIN_CODE_NAME);
		instantiateProposalRequest.setChaincodePath("github.com/gov");
		instantiateProposalRequest.setArgs("A", "100", "B", "200");
		instantiateProposalRequest.setChaincodeLanguage(Type.GO_LANG);
		instantiateProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
		Map<String, byte[]> tm = new HashMap<>();
		tm.put("HyperLedgerFabric", "InstantiateProposalRequest:JavaSDK".getBytes(UTF_8));
		tm.put("method", "InstantiateProposalRequest".getBytes(UTF_8));
		instantiateProposalRequest.setTransientMap(tm);
		instantiateProposalRequest.setProposalWaitTime(TestConfig.getConfig().getProposalWaitTime());
		instantiateProposalRequest.setTransientMap(tm);
		ChaincodeEndorsementPolicy chaincodeEndorsementPolicy = new ChaincodeEndorsementPolicy();
		chaincodeEndorsementPolicy
				.fromYamlFile(new File(TEST_FIXTURES_PATH + "/sdkintegration/mpscpairall.yaml"));
		instantiateProposalRequest.setChaincodeEndorsementPolicy(chaincodeEndorsementPolicy);
		//instantiateProposalRequest.setChaincodeCollectionConfiguration(ChaincodeCollectionConfiguration.fromYamlFile(new File("src/test/fixture/collectionProperties/tf.yaml")));
	
		Collection<ProposalResponse> proposalResponse = testChannel
				.sendInstantiationProposal(instantiateProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}


		testChannel.sendTransaction(proposalResponse, hfclient.getUserContext());
		
			
	}
	
	public static void upgradeChaincode(Channel testChannel)
			throws InvalidArgumentException, ProposalException, ChaincodeEndorsementPolicyParseException, IOException,
			InterruptedException, ExecutionException, TimeoutException, ChaincodeCollectionConfigurationException {
			UpgradeProposalRequest instantiateProposalRequest = hfclient.newUpgradeProposalRequest();
		instantiateProposalRequest.setChaincodeName(CHAIN_CODE_NAME);
		instantiateProposalRequest.setChaincodePath("github.com/gov");
		instantiateProposalRequest.setArgs("A", "100", "B", "200");
		instantiateProposalRequest.setChaincodeLanguage(Type.GO_LANG);
		instantiateProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
		Map<String, byte[]> tm = new HashMap<>();
		tm.put("HyperLedgerFabric", "UpgradeProposalRequest:JavaSDK".getBytes(UTF_8));
		tm.put("method", "UpgradeProposalRequest".getBytes(UTF_8));
		instantiateProposalRequest.setTransientMap(tm);
		instantiateProposalRequest.setProposalWaitTime(TestConfig.getConfig().getProposalWaitTime());
		instantiateProposalRequest.setTransientMap(tm);
		ChaincodeEndorsementPolicy chaincodeEndorsementPolicy = new ChaincodeEndorsementPolicy();
		chaincodeEndorsementPolicy
				.fromYamlFile(new File(TEST_FIXTURES_PATH + "/sdkintegration/mpscpair.yaml"));
		instantiateProposalRequest.setChaincodeEndorsementPolicy(chaincodeEndorsementPolicy);
		//instantiateProposalRequest.setChaincodeCollectionConfiguration(ChaincodeCollectionConfiguration.fromYamlFile(new File("src/test/fixture/collectionProperties/tf.yaml")));
	
		Collection<ProposalResponse> proposalResponse = testChannel
				.sendUpgradeProposal(instantiateProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}


		testChannel.sendTransaction(proposalResponse, hfclient.getUserContext());
		
			
	}

	public static void instantiateChaincodeNode(Channel testChannel)
			throws InvalidArgumentException, ProposalException, ChaincodeEndorsementPolicyParseException, IOException,
			InterruptedException, ExecutionException, TimeoutException {
		InstantiateProposalRequest instantiateProposalRequest = hfclient.newInstantiationProposalRequest();
		instantiateProposalRequest.setChaincodeName(NODE_CHAIN_CODE_NAME);
		// instantiateProposalRequest.setChaincodePath("github.com/example_cc");
		instantiateProposalRequest.setArgs("A", "100", "B", "200");
		instantiateProposalRequest.setChaincodeLanguage(Type.NODE);
		instantiateProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
		Map<String, byte[]> tm = new HashMap<>();
		tm.put("HyperLedgerFabric", "InstantiateProposalRequest:NodeSDK".getBytes(UTF_8));
		tm.put("method", "InstantiateProposalRequest".getBytes(UTF_8));
		instantiateProposalRequest.setTransientMap(tm);
		instantiateProposalRequest.setProposalWaitTime(TestConfig.getConfig().getProposalWaitTime());
		instantiateProposalRequest.setTransientMap(tm);
		ChaincodeEndorsementPolicy chaincodeEndorsementPolicy = new ChaincodeEndorsementPolicy();
		chaincodeEndorsementPolicy
				.fromYamlFile(new File(TEST_FIXTURES_PATH + "/sdkintegration/chaincodeendorsementpolicy.yaml"));
		instantiateProposalRequest.setChaincodeEndorsementPolicy(chaincodeEndorsementPolicy);
		Collection<ProposalResponse> proposalResponse = testChannel
				.sendInstantiationProposal(instantiateProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}

		TestConfig testConfig = TestConfig.getConfig();

		testChannel.sendTransaction(proposalResponse, hfclient.getUserContext()).thenApply(transactionEvent -> {
			try {

			 // must be valid to be
														// here.
				System.out
						.println("Finished transaction with transaction id %s " + transactionEvent.getTransactionID());
				String testTxID = transactionEvent.getTransactionID(); // used
																		// in
																		// the
				// channel
				// queries later

				////////////////////////////
				// Send Query Proposal to all peers
				//
				int delta = 30;
				String expect = "" + (300 + delta);
				System.out.println("Now query chaincode for the value of b.");
				QueryByChaincodeRequest queryByChaincodeRequest = hfclient.newQueryProposalRequest();
				queryByChaincodeRequest.setArgs(new String[] { "b" });
				queryByChaincodeRequest.setFcn("query");
				ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(NODE_CHAIN_CODE_NAME).build();
				queryByChaincodeRequest.setChaincodeID(chaincodeID);

				Map<String, byte[]> tm2 = new HashMap<>();
				tm2.put("HyperLedgerFabric", "QueryByChaincodeRequest:NodeSDK".getBytes(UTF_8));
				tm2.put("method", "QueryByChaincodeRequest".getBytes(UTF_8));
				queryByChaincodeRequest.setTransientMap(tm2);

				Collection<ProposalResponse> queryProposals = testChannel.queryByChaincode(queryByChaincodeRequest);
				for (ProposalResponse proposalResponse2 : queryProposals) {
					if (!proposalResponse2.isVerified()
							|| proposalResponse2.getStatus() != ProposalResponse.Status.SUCCESS) {
					
					} else {
						String payload = proposalResponse2.getProposalResponse().getResponse().getPayload()
								.toStringUtf8();
						System.out.println(
								"Query payload of b from peer %s returned  " + proposalResponse2.getPeer().getName());
						// assertEquals(payload, expect);
					}
				}

				return null;
			} catch (Exception e) {
				System.err.println("Caught exception while running query");
				e.printStackTrace();
			}

			return null;
		}).exceptionally(e -> {
			if (e instanceof TransactionEventException) {
				BlockEvent.TransactionEvent te = ((TransactionEventException) e).getTransactionEvent();
				if (te != null) {
					throw new AssertionError(
							format("Transaction with txid %s failed. %s", te.getTransactionID(), e.getMessage()), e);
				}
			}

			throw new AssertionError(format("Test failed with %s exception %s", e.getClass().getName(), e.getMessage()),
					e);

		}).get(testConfig.getTransactionWaitTime(), TimeUnit.SECONDS);
	}


	public static CompletableFuture<BlockEvent.TransactionEvent> genUPCC(Channel testChannel, String fuc,String... args) 
			throws ProposalException, InvalidArgumentException, ServiceDiscoveryException {
		TransactionProposalRequest transactionProposalRequest = hfclient.newTransactionProposalRequest();
		
    //tf
	//	transactionProposalRequest.setFcn("createWallet");
	//	transactionProposalRequest.setFcn("appendDocument");
	//	transactionProposalRequest.setFcn("createEntity");
	//	transactionProposalRequest.setFcn("addBalance");
		transactionProposalRequest.setFcn(fuc);
	//	transactionProposalRequest.setFcn("recordBOLGeneration");
	//	transactionProposalRequest.setFcn("getAllLc");
		
	//mnp	
	//transactionProposalRequest.setFcn("getReportForOperator");
	//transactionProposalRequest.setFcn("getReportForNumber");
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).setVersion(CHAIN_CODE_VERSION).build();

		transactionProposalRequest.setChaincodeID(chaincodeID);

		transactionProposalRequest.setArgs(args);
		// transactionProposalRequest.setArgs("CAR11", "Chevy1", "Volt1",
		// "Red1", "Nick1");
		Collection<ProposalResponse> proposalResponses = testChannel
				.sendTransactionProposal(transactionProposalRequest);
/*
		 Collection<ProposalResponse> proposalResponses =
		         testChannel.sendTransactionProposalToEndorsers(transactionProposalRequest,
		                 createDiscoveryOptions().setEndorsementSelector(EndorsementSelector.ENDORSEMENT_SELECTION_RANDOM));*/

		for (ProposalResponse proposalResponse : proposalResponses) {

			System.out.println( new String(proposalResponse.getProposalResponse().getResponse().getPayload().toByteArray()));
		}
		return testChannel.sendTransaction(proposalResponses, hfclient.getUserContext());
		

	}
	
	
	public static QueryByChaincodeRequest queryAllcars() {
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName("fabcar").build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setFcn("queryAllCars");
		return queryByChaincodeRequest;
	}

	public static QueryByChaincodeRequest queryOnecar(String carname) {
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName("fabcar").build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setFcn("queryCar");
		queryByChaincodeRequest.setArgs(carname);
		return queryByChaincodeRequest;
	}
	public static QueryByChaincodeRequest queryOp(String number) {
		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setFcn("getOP");
		queryByChaincodeRequest.setArgs(number);
		return queryByChaincodeRequest;
	}
	static File findFileSk(String directorys) {

		File directory = new File(directorys);

		File[] matches = directory.listFiles((dir, name) -> name.endsWith("_sk"));

		if (null == matches) {
			throw new RuntimeException(
					format("Matches returned null does %s directory exist?", directory.getAbsoluteFile().getName()));
		}

		if (matches.length != 1) {
			throw new RuntimeException(format("Expected in %s only 1 sk file but found %d",
					directory.getAbsoluteFile().getName(), matches.length));
		}

		return matches[0];

	}
	
	public static void upgradeChaincodeNode(Channel testChannel)
			throws InvalidArgumentException, ProposalException, ChaincodeEndorsementPolicyParseException, IOException,
			InterruptedException, ExecutionException, TimeoutException {
		
		UpgradeProposalRequest upgradeProposalRequest = hfclient.newUpgradeProposalRequest();
		upgradeProposalRequest.setChaincodeName(CHAIN_CODE_NAME);
		upgradeProposalRequest.setChaincodePath("github.com/mnp");
		upgradeProposalRequest.setArgs("");
		upgradeProposalRequest.setChaincodeLanguage(Type.GO_LANG);
		upgradeProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
		Map<String, byte[]> tm = new HashMap<>();
		tm.put("HyperLedgerFabric", "UpgradeProposalRequest:JavaSDK".getBytes(UTF_8));
		tm.put("method", "UpgradeProposalRequest".getBytes(UTF_8));
		upgradeProposalRequest.setTransientMap(tm);
		upgradeProposalRequest.setProposalWaitTime(TestConfig.getConfig().getProposalWaitTime());
		upgradeProposalRequest.setTransientMap(tm);
		ChaincodeEndorsementPolicy chaincodeEndorsementPolicy = new ChaincodeEndorsementPolicy();
		chaincodeEndorsementPolicy
				.fromYamlFile(new File(TEST_FIXTURES_PATH + "/sdkintegration/chaincodeendorsementpolicy.yaml"));
		upgradeProposalRequest.setChaincodeEndorsementPolicy(chaincodeEndorsementPolicy);
		Collection<ProposalResponse> proposalResponse = testChannel
				.sendUpgradeProposal(upgradeProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}

		
	}
}