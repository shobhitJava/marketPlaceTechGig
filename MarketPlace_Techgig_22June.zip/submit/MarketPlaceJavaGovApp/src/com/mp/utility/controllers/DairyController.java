package com.mp.utility.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mp.utility.models.Dairy;
import com.mp.utility.services.DairyDataService;

@Controller
@RequestMapping({"/api/dairy"})
public class DairyController
{
  @Autowired
  private DairyDataService dairyDataService;
  
  public DairyController() {}
  
  @RequestMapping(value={"/registerProfile"}, method={org.springframework.web.bind.annotation.RequestMethod.POST})
  @ResponseBody
  public Dairy saveUser(@RequestBody Dairy dairy)
  {
	  
    return dairyDataService.saveDairyProfile(dairy);
  }
  
  @RequestMapping(value={"/getDairyProfile/{dairyId}"}, method={org.springframework.web.bind.annotation.RequestMethod.GET})
  @ResponseBody
  public Dairy getDairyProfile(@PathVariable("dairyId") String dairyId)
  {
    return dairyDataService.getDairyProfile(dairyId);
  }
  
  @RequestMapping(value={"/rating"}, method={org.springframework.web.bind.annotation.RequestMethod.POST}, consumes={"application/json"})
  @ResponseBody
  public boolean rating(@RequestBody String json)
  {
    boolean res = false;
    if (dairyDataService.rate(json)) {
      res = true;
    }
    return res;
  }
}
 
