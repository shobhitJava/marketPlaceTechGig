package com.mp.utility.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mp.utility.models.Doctor;
import com.mp.utility.models.User;
import com.mp.utility.services.GovDataService;

@Controller
@RequestMapping("/api/gov")

public class GovController {

	@Autowired
	private GovDataService govDataService;


	@RequestMapping(value = "/getAllFarmers", method = RequestMethod.GET)
	@ResponseBody
	public List<User> getAllFarmers() {

		return govDataService.getAllFarmers();

	}

	@RequestMapping(value = "/getAllDocs", method = RequestMethod.GET)
	@ResponseBody
	public List<Doctor> getAllDocs() {

		return govDataService.getAllDocs();

	}@RequestMapping(value = "/getAllCows", method = RequestMethod.GET)
	@ResponseBody
	public String getAllCows() {

		return govDataService.getAllCows();

	}@RequestMapping(value = "/getAllTx", method = RequestMethod.GET)
	@ResponseBody
	public String getAllTx() {

		return govDataService.getAllTx();

	}
	

}
