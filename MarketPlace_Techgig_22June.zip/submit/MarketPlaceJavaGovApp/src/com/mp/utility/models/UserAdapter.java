package com.mp.utility.models;

import java.lang.reflect.Type;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

public class UserAdapter implements JsonSerializer<User> {

@Override
public JsonElement serialize(final User stats, final Type typeOfSrc, final JsonSerializationContext context) { 
       final JsonObject jsonObject = new JsonObject();
     //  jsonObject.addProperty("_id", stats.getId());
       // ... just the same thing for others attributes.
       return jsonObject;
    }


}
