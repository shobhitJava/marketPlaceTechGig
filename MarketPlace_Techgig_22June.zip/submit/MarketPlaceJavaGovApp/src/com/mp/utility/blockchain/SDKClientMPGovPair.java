package com.mp.utility.blockchain;

import static java.lang.String.format;
import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hyperledger.fabric.sdk.ChaincodeID;
import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.HFClient;
import org.hyperledger.fabric.sdk.Orderer;
import org.hyperledger.fabric.sdk.Peer;
import org.hyperledger.fabric.sdk.ProposalResponse;
import org.hyperledger.fabric.sdk.QueryByChaincodeRequest;
import org.hyperledger.fabric.sdk.TransactionProposalRequest;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.exception.ServiceDiscoveryException;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

@Component
public class SDKClientMPGovPair {

	private static final String CHANNEL_NAME = "pairchannel";
	static HFClient hfclient = null;
	private static final String USER_NAME = "admin";
	private static final String USER_MSP_ID = "governmentMSP";

	private static final String CHAIN_CODE_NAME = "mpp6";
	private static final String CHAIN_CODE_VERSION = "1";
	private static final String PEER2_ADDRESS = "grpc://10.64.217.120:7059";
	
	private static final String PEER2_NAME = "peer0.docs.test";
	private static final String PEER1_ADDRESS = "grpc://10.64.217.120:7060";
	private static final String PEER1_NAME = "peer0.government.test";
	private static final String ORDERER1_NAME = "orderer.mp.test";
	private static final String ORDERER1_ADDRESS = "grpc://10.64.217.120:7050";
	private static final String keystoreLocation = "priv_sk";
	private static final String usercertfile = "Admin@gov.test-cert.pem";
	private static final String orgName = "gov.test";
	Logger logger = Logger.getLogger(SDKClientMPGovPair.class);

	public String create( String function, String flag, String... args) {

		String res = "";
		try {
			System.out.println("initialize logger");

			File sampleStoreFile = new File(System.getProperty("user.home") + "/test.properties");

			if (sampleStoreFile.exists()) { // For testing start fresh
				sampleStoreFile.delete();
			}
			final SDKStore sdkStore = new SDKStore(sampleStoreFile);

			File key = ResourceUtils.getFile("classpath:"+keystoreLocation);

			File cert = ResourceUtils.getFile("classpath:" + usercertfile + "");
			logger.info("creating sdk user object");
			SDKUser someTestUSER = sdkStore.getMember(USER_NAME, orgName, USER_MSP_ID, key, cert);

			someTestUSER.setMspId(USER_MSP_ID);

			File tempFile = File.createTempFile("teststore", "properties");

			tempFile.deleteOnExit();

			hfclient = HFClient.createNewInstance();

			hfclient.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());
			hfclient.setUserContext(someTestUSER);

			logger.info("creating sdk user object");

			Channel testChannel = hfclient.newChannel(CHANNEL_NAME);

			Peer peer1 = hfclient.newPeer(PEER1_NAME, PEER1_ADDRESS);
			Peer peer2 = hfclient.newPeer(PEER2_NAME, PEER2_ADDRESS);

			Orderer orderer = hfclient.newOrderer(ORDERER1_NAME, ORDERER1_ADDRESS);
			System.out.println("adding peer " + PEER1_NAME);
			testChannel.addPeer(peer1);
			testChannel.addPeer(peer2);
			System.out.println("adding orderer " + ORDERER1_NAME);
			testChannel.addOrderer(orderer);

			testChannel.initialize();
			logger.info("Channel intialized successfully");
			if(flag.equalsIgnoreCase("invoke")) {
				res = invoke(testChannel, function,  args );
	
			}else {
				testChannel.removePeer(peer2);
			res = query( args , testChannel, function)	;
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return res;
	}

	public String invoke(Channel testChannel, String function, String... args)
			throws ProposalException, InvalidArgumentException, ServiceDiscoveryException {
		String res = "";
		TransactionProposalRequest transactionProposalRequest = hfclient.newTransactionProposalRequest();

		transactionProposalRequest.setFcn(function);

		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).setVersion(CHAIN_CODE_VERSION)
				.build();

		transactionProposalRequest.setChaincodeID(chaincodeID);

		transactionProposalRequest.setArgs(args);
		Collection<ProposalResponse> proposalResponses = testChannel
				.sendTransactionProposal(transactionProposalRequest);

		for (ProposalResponse proposalResponse : proposalResponses) {

			res = new String(proposalResponse.getProposalResponse().getResponse().getPayload().toByteArray());

		}

		testChannel.sendTransaction(proposalResponses, hfclient.getUserContext());
		testChannel.shutdown(true);
		return res;

	}

	public static String query(String[] args, Channel channel, String functionName)
			throws InvalidArgumentException, ProposalException {
		String payload = null;

		QueryByChaincodeRequest queryByChaincodeRequest = QueryByChaincodeRequest
				.newInstance(hfclient.getUserContext());

		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(CHAIN_CODE_NAME).setVersion(CHAIN_CODE_VERSION)
				.build();
		queryByChaincodeRequest.setChaincodeID(chaincodeID);
		queryByChaincodeRequest.setFcn(functionName);
		queryByChaincodeRequest.setArgs(args);
		Map<String, byte[]> tm2 = new HashMap<>();
		tm2.put("HyperLedgerFabric", "QueryByChaincodeRequest:JavaSDK".getBytes(UTF_8));
		tm2.put("method", functionName.getBytes(UTF_8));
		queryByChaincodeRequest.setTransientMap(tm2);

		Collection<ProposalResponse> queryProposals = channel.queryByChaincode(queryByChaincodeRequest);
		for (ProposalResponse proposalResponse2 : queryProposals) {
			if (!proposalResponse2.isVerified() || proposalResponse2.getStatus() != ProposalResponse.Status.SUCCESS) {

			} else {
				payload = proposalResponse2.getProposalResponse().getResponse().getPayload().toStringUtf8();
				System.out.println(proposalResponse2.getProposalResponse().getResponse().getPayload().toStringUtf8());

			}
		}
		channel.shutdown(true);
		return payload;
	}

	static File findFileSk(String directorys) {

		File directory = new File(directorys);

		File[] matches = directory.listFiles((dir, name) -> name.endsWith("_sk"));

		if (null == matches) {
			throw new RuntimeException(
					format("Matches returned null does %s directory exist?", directory.getAbsoluteFile().getName()));
		}

		if (matches.length != 1) {
			throw new RuntimeException(format("Expected in %s only 1 sk file but found %d",
					directory.getAbsoluteFile().getName(), matches.length));
		}

		return matches[0];

	}

}