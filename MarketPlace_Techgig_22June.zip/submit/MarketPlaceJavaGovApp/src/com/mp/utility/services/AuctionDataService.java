package com.mp.utility.services;

public interface AuctionDataService {
	


	 String getAllMilk();
	 boolean bidForMilk(String bid);
	
	
	
	 
}
