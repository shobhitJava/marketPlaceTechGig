package com.mp.utility.services;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mp.utility.blockchain.SDKClientMPCommonD1;
import com.mp.utility.models.Dairy;
import com.mp.utility.persistence.DairyDB;

@Service
public class DairyServiceImpl implements DairyDataService {

	@Autowired
	SDKClientMPCommonD1 sdkClientMPCommonD1;
	@Autowired
	DairyDB dairyDB;
	
	String invoke = "invoke";


	

	@Override
	public Dairy saveDairyProfile(Dairy dairy) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			byte[] messageDigest = md.digest(dairy.getMobile().getBytes());
			BigInteger no = new BigInteger(1, messageDigest);
			String id = no.toString(16);
			dairy.setDairyId(id);
			dairyDB.saveDoctor(dairy);
					
		} catch (NoSuchAlgorithmException e) {
		}
		return dairy;
	}

	@Override
	public Dairy getDairyProfile(String dairyId) {
		return dairyDB.getDoctorProfile(dairyId);

	}

	@Override
	public boolean rate(String json) {
		String res = sdkClientMPCommonD1.create("rating", invoke, json);
		System.out.println(res);
		return res.startsWith("RATING") ? true : false;
	}

}
