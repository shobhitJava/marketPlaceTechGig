package com.mp.utility.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mp.utility.blockchain.SDKClientMP;
import com.mp.utility.blockchain.SDKClientMPCommonGov;
import com.mp.utility.blockchain.SDKClientMPGovPair;
import com.mp.utility.models.Doctor;
import com.mp.utility.models.User;
import com.mp.utility.persistence.UserDB;

@Service
public class GovServiceImpl implements GovDataService {
	@Autowired
	SDKClientMPCommonGov sdkClientMPCommonGov;

	@Autowired
	SDKClientMPGovPair sdkClientMPGovPair;
	@Autowired
	SDKClientMP sdkClientMP;
	@Autowired
	UserDB userDB;

	String invoke = "invoke";


	
	@Override
	public List<User> getAllFarmers() {
	return	userDB.getAllFarmer();
	}

	@Override
	public List<Doctor> getAllDocs() {
		return userDB.getAllDoctor();
	}

	@Override
	public String getAllCows() {
		String res = sdkClientMPGovPair.create("getAllEntities", "query", "COW");

		return res;
	}

	@Override
	public String getAllTx() {
		String res = sdkClientMPGovPair.create("getAllEntities", "query", "transaction");

		return res;
	}


}
