package com.mp.utility.services;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mp.utility.blockchain.SDKClientMP;
import com.mp.utility.blockchain.SDKClientMPCommonGov;
import com.mp.utility.blockchain.SDKClientMPGovPair;
import com.mp.utility.models.SearchFilter;
import com.mp.utility.models.User;
import com.mp.utility.persistence.UserDB;

@Service
public class DataServiceImpl implements UserDataService {
	@Autowired
	SDKClientMPCommonGov sdkClientMPCommonGov;

	@Autowired
	SDKClientMPGovPair sdkClientMPGovPair;
	@Autowired
	SDKClientMP sdkClientMP;
	@Autowired
	UserDB userDB;

	String invoke = "invoke";

	@Override
	public boolean saveFarmerProfile(User user) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			byte[] messageDigest = md.digest(user.getAadharId().getBytes());
			BigInteger no = new BigInteger(1, messageDigest);
			String res = sdkClientMP.create(no.toString(16), "createUserMapping");
			if (res.isEmpty()) {
				return false;
			}
			user.setfarmerId(res);
		} catch (NoSuchAlgorithmException e) {
			return false;
		}
		return userDB.uploadUser(user);
	}

	@Override
	public boolean addCow(String cow) {
		String res = sdkClientMPGovPair.create("createEntity", invoke, cow);
		System.out.println(res);
		return res.startsWith("COW") ? true : false;
	}

	@Override
	public boolean updateCow(String cow) {//
		String res = sdkClientMPGovPair.create("appendDocument", invoke, cow);
		System.out.println(res);
		return res.equalsIgnoreCase("Success") ? true : false;

	}

	@Override
	public boolean markCowOnSale(String cowId, String json) {
		String res = sdkClientMPGovPair.create("markCowOnSale", invoke, cowId, json);
		System.out.println(res);
		return res.equalsIgnoreCase("true") ? true : false;
	}

	@Override
	public boolean bidForCow(String bid) {
		String res = sdkClientMPGovPair.create("bidForCow", invoke, bid);
		System.out.println(res);
		return res.startsWith("bid") ? true : false;
	}

	@Override
	public User getFarmerProfile(String farmerId) {

		return userDB.getFarmerProfile(farmerId);
	}

	@Override
	public String getAllCow(String farmerId) {
		String res = sdkClientMPGovPair.create("getAllCowsData", "query", "farmerId", farmerId);

		return res;
	}

	@Override
	public String getCowsInAuction(SearchFilter json) {
		String args[] = { "breed", json.getBreed(), "tehsil", json.getTehsil(), json.getMinAge(), json.getMaxAge() };
		String res = sdkClientMPGovPair.create("filterCowsAvailableForSale", "query", args);

		return res;
	}

	@Override
	public boolean auctionMilk(String milk) {
		String res = sdkClientMPCommonGov.create("addMilk", invoke, milk);
		System.out.println(res);
		return res.startsWith("MILK") ? true : false;
	}

	@Override
	public boolean acceptBidForMilk(String bid) {
		String res = sdkClientMPGovPair.create("acceptBidMilk", invoke, bid);
		System.out.println(res);
		return res.equalsIgnoreCase("true") ? true : false;
	}

	@Override
	public boolean payment(String json) {
		String res = sdkClientMPGovPair.create("payment", invoke, json);
		System.out.println(res);
		return res.equalsIgnoreCase("true") ? true : false;
	}

	@Override
	public boolean rate(String json) {
		String res = sdkClientMPGovPair.create("rating", invoke, json);
		System.out.println(res);
		return res.startsWith("RATING") ? true : false;
	}


}
