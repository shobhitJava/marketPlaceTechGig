package com.mp.utility.services;

import com.mp.utility.models.Doctor;

public interface DocDataService {
	
	String saveDoctorProfile(Doctor doctor);

	 boolean updateCow(String cowId,String json);

	 Doctor getDoctorProfile(String doctorId);
	 String getAllCow(String tehsil, String district);
	
	
	 
}
