package com.mp.utility.services;

import com.mp.utility.models.Dairy;

public interface DairyDataService {
	
	Dairy saveDairyProfile(Dairy dairy);

	 Dairy getDairyProfile(String dairyId);

	 boolean rate(String json);
	
	 
}
