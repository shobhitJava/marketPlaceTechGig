package com.mp.utility.services;

public interface RatingDataService {
	


	 
	 boolean rateFarmer(String rating);
	
	
	
	 
}
