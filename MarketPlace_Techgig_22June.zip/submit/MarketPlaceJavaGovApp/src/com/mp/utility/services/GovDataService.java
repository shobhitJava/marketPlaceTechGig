package com.mp.utility.services;

import java.util.List;

import com.mp.utility.models.Doctor;
import com.mp.utility.models.User;

public interface GovDataService {
	List<User> getAllFarmers();
	List<Doctor> getAllDocs();
	String getAllCows();
	String getAllTx();
}
