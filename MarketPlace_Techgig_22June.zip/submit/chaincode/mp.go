/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/* @author Shobhit Srivastava  22 June 2019
 * Sample smart contract for MarketPlace Techgig solution
 *
 */
package main

/* Imports
 * 4 utility libraries for formatting, handling bytes, reading and writing JSON, and string manipulation
 * 2 specific Hyperledger Fabric specific libraries for Smart Contracts
 */
import (
  "fmt"
  "strconv"
   "encoding/json"
  "bytes"
  "strings"
  "github.com/hyperledger/fabric/core/chaincode/shim"
  sc "github.com/hyperledger/fabric/protos/peer"
  "time"
  "math"
  
)


const COW_PREFIX = "COW"
const MP_KEY = "MP_KEY"
const BID_KEY = "COWBID"
const MILK_KEY = "MILK"
const BID_KEY_MILK = "MILKBID"
const PAYMENT_TXN = "PAYMENT_TXN"
const RATING = "RATING"

// Define the Smart Contract structure
type SmartContract struct {
}
/*
 * The Init method is called when the Smart Contract "MarketPlace" is instantiated by the blockchain network
 * Best practice is to have any Ledger initialization in separate function -- see initLedger()
 */
func (s *SmartContract) Init(APIstub shim.ChaincodeStubInterface) sc.Response {
  fmt.Println("MarketPlace Techgig chaincode initialized ")
  APIstub.PutState(MP_KEY, []byte("0"))
  APIstub.PutState(BID_KEY, []byte("0"))
  APIstub.PutState(MILK_KEY, []byte("0"))
  APIstub.PutState(BID_KEY_MILK, []byte("0"))
  APIstub.PutState(PAYMENT_TXN, []byte("0"))
  APIstub.PutState(RATING, []byte("0"))
  return shim.Success(nil)
}

/*
 * The Invoke method is called as a result of an application request to run the Smart Contract "fabcar"
 * The calling application program has also specified the particular smart contract function to be called, with arguments
 */
func (s *SmartContract) Invoke(APIstub shim.ChaincodeStubInterface) sc.Response {

  // Retrieve the requested Smart Contract function and arguments
  function, args := APIstub.GetFunctionAndParameters()
  // Route to the appropriate handler function to interact with the ledger appropriately 
  if function == "createUserMapping" {
    return s.createUserMapping(APIstub, args)  
  } else if function == "createEntity" {
    return s.createEntity(APIstub, args)
  } else if function == "getData" {
    return s.getData(APIstub, args)
  } else if function == "createWallet" {
    return s.createWallet(APIstub, args)
  } else if function == "appendDocument" {
    return s.appendDocument(APIstub, args)
  } else if function == "addBalance" {
    return s.addBalance(APIstub, args)
  } else if function == "markCowOnSale" {
    return s.markCowOnSale(APIstub, args)
  } else if function == "filterCowsAvailableForSale" {
    return s.filterCowsAvailableForSale(APIstub, args)
  } else if function == "bidForCow" {
    return s.bidForCow(APIstub, args)
  } else if function == "acceptBid" {
    return s.acceptBid(APIstub, args)
  } else if function == "addMilk" {
    return s.addMilk(APIstub, args)
  } else if function == "getMilkAvailableForSale" {
    return s.getMilkAvailableForSale(APIstub, args)
  } else if function == "bidForMilk" {
    return s.bidForMilk(APIstub, args)
  } else if function == "acceptBidMilk" {
    return s.acceptBidMilk(APIstub, args)
  } else if function == "getAllCowsData" {
    return s.getAllCowsData(APIstub, args)
  } else if function == "updateCowHealth" {
    return s.updateCowHealth(APIstub, args)
  } else if function == "payment" {
    return s.payment(APIstub, args)
  } else if function == "getWalletDetails" {
    return s.getWalletDetails(APIstub, args)
  } else if function == "rating" {
    return s.rating(APIstub, args)
  } else if function == "getMilkSuggestedPriceForSale" {
    return s.getMilkSuggestedPriceForSale(APIstub, args)
  } else if function == "gaussianDistance" {
    return s.gaussianDistance(APIstub, args)
  } else if function == "deleteCow" {
    return s.deleteCow(APIstub, args)
  } else if function == "getAvailableMilkQuantity" {
    return s.getAvailableMilkQuantity(APIstub, args)
  }  else if function == "getAllRecordType" {
    return s.getAllRecordType(APIstub, args)
  }  else if function == "getAvgPriceForCowBreed" {
    return s.getAvgPriceForCowBreed(APIstub, args)
  } else if function == "getAllFarmerBids" {
    return s.getAllFarmerBids(APIstub, args)
  } else if function == "getAllEntities" {
    return s.getAllEntities(APIstub, args)
  } 
  return shim.Error("Invalid Smart Contract function name.")
}

/*
 *This method is for creating digitalId in marketplace  
 */
func (s *SmartContract) createUserMapping(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  
  if len(args) < 1  {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }

  	now := time.Now()
	secs := now.Unix()
	walletId := strconv.FormatInt(secs, 10)
	fmt.Printf("wallet id is: %s", walletId)
   	APIstub.PutState(args[0], []byte(args[0]+walletId) )
  	return shim.Success([]byte(args[0]+walletId))
}
/*
 *This method is for getting digitalId and other entities in marketplace
 */
func (s *SmartContract) getData(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  
  if len(args) < 1  {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }
  	wallet_Bytes, _ := 	APIstub.GetState(args[0] )
   	if(wallet_Bytes  == nil){
      return shim.Error("Error occured")
    }
  	return shim.Success(wallet_Bytes)
}

/*
 *This method is to archive the cow data from ledger
 */
func (s *SmartContract) deleteCow(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	  if len(args) <= 1 {
	    return shim.Error("Incorrect number of arguments. Expecting 1 args")
	   }
   
	  var cow map[string]interface{}
		
	  recAsBytes, _ := APIstub.GetState(args[0])
	   if(recAsBytes  == nil){
      return shim.Error("No Record with this number")
	    }
	  json.Unmarshal(recAsBytes, &cow)
	  if cow["OnSale"] == "true" {
	  return shim.Success([]byte("false"))
	  } else {
	  cow["status"] = "archived"
	  }
	  mapData, _ := json.Marshal(cow) 
	  APIstub.PutState(args[0], mapData)
	  return shim.Success([]byte("Success"))
}


/*
 *This method is for creating wallet  in marketplace
 */
func (s *SmartContract) createWallet(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  
  if len(args) < 1  {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }
  	var wallet map[string]string
  	wallet = make(map[string]string , 0)
   wallet["balance"] = "0"
   wallet["status"]  = "ACTIVE"
   walletBytes,_ := json.Marshal(wallet)
   	APIstub.PutState(args[0], walletBytes)
  	return shim.Success([]byte("true"))
}

/*
 *This method is for creating digital entity in marketplace
 */
func (s *SmartContract) createEntity(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  
  if len(args) < 1  {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }
  	var entity map[string]string
    json.Unmarshal([]byte(args[0]), &entity)
	
	  cow_numberBytes,_ := APIstub.GetState(MP_KEY)
    if cow_numberBytes  == nil {
      return shim.Error("Error occured")
    }
   cow_number, _:= strconv.Atoi((string)(cow_numberBytes))  
   cow_number = cow_number + 1
   
   co_numberString := strconv.Itoa(cow_number)
 
    fmt.Printf("cow id is: %s", cow_number)
	entity["cowId"] = COW_PREFIX+ co_numberString
	entity["type"] = "COW"
	entity["status"] = "BORN"
	entity["noOfOwner"] = "X"
	entity["noOfbids"] = "S"
	cow,_ := json.Marshal(entity)
   	APIstub.PutState(entity["cowId"], cow)
   	APIstub.PutState(MP_KEY, []byte(co_numberString))
  	return shim.Success([]byte(entity["cowId"]))
}

/*
 *This method will update the key with newer value inside a json
 */   
func (s *SmartContract) appendDocument(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	  if len(args) <= 1 {
	    return shim.Error("Incorrect number of arguments. Expecting 2 args")
	   }
      var existingRecMap map[string]interface{}
	  var appendFields map[string]interface{}
		
	  recAsBytes, _ := APIstub.GetState(args[0])
	   if(recAsBytes  == nil){
      return shim.Error("No Record with this number")
	    }
	  json.Unmarshal(recAsBytes, &existingRecMap)
	   fmt.Println(args[1])
	  payload := args[1]
	  json.Unmarshal([]byte(payload), &appendFields)
	  fmt.Println(appendFields)
	  for key, value := range appendFields {
					
					fmt.Println("new key is " + key)
					existingRecMap[key] = value
				}	  
	  mapData, _ := json.Marshal(existingRecMap) 
	  fmt.Println("new Payload is " + string(mapData))
	  //to do validation if any in future
	  APIstub.PutState(args[0], mapData)
	  return shim.Success([]byte("Success"))
}


/*
 *This method will update the health of a cow
 */   
func (s *SmartContract) updateCowHealth(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	  if len(args) <= 1 {
	    return shim.Error("Incorrect number of arguments. Expecting 2 args")
	   }
      var existingRecMap map[string]interface{}
	  var appendFields map[string]interface{}
	  
	  var health interface{}
		
	  recAsBytes, _ := APIstub.GetState(args[0])
	   if(recAsBytes  == nil){
      return shim.Error("No Record with this number")
	    }
	  json.Unmarshal(recAsBytes, &existingRecMap)
	  
	  payload := args[1]
	  json.Unmarshal([]byte(payload), &appendFields)
	  
	 	 b, err := json.Marshal(appendFields["healthRecord"])
			if err != nil {
		panic(err)
		}
	  
	  err = json.Unmarshal(b, &health)
		if err != nil {
			panic(err)
		}
		md, _:= health.(map[string]interface{})
	
	  if _, ok := existingRecMap["healthRecord"]; ok {
	  res := appendFields["healthRecord"]
    existingRecMap["healthRecord"] = append([]interface{}{existingRecMap["healthRecord"]},res)
		
	  } else {
	  existingRecMap["healthRecord"] = appendFields["healthRecord"]
	  }
	   existingRecMap["lastHealthCheck"] = md["checkUpTime"]
	  delete(appendFields,"healthRecord")
	  for key, value := range appendFields {
					
					fmt.Println("new key is " + key)
					existingRecMap[key] = value
				}	
	existingRecMap["requestHealthCert"] ="false"
	  mapData, _ := json.Marshal(existingRecMap) 
	  fmt.Println("new Payload is " + string(mapData))
	  //to do validation if any in future
	  APIstub.PutState(args[0], mapData)
	  return shim.Success([]byte("Success"))
}

/*
 *This method is for adding balance in wallet in marketplace
 */
func (s *SmartContract) addBalance(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  
  if len(args) < 1  {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }
  	var wallet map[string]string
  	wallet_Bytes, _ := 	APIstub.GetState(args[0] )
   	if(wallet_Bytes  == nil){
      return shim.Error("Error occured")
    }
     json.Unmarshal(wallet_Bytes, &wallet)
     balance,_  := strconv.Atoi(wallet["balance"])
     addBalance,_ := strconv.Atoi(args[1])
     balance = balance + addBalance
     wallet["balance"] = strconv.Itoa(balance)
     walletBytes,_:=json.Marshal(wallet)
  	 APIstub.PutState(args[0], walletBytes)
  	 return shim.Success([]byte("true"))
}


/*
 *This method is for doing payment in marketplace
 */
func (s *SmartContract) payment(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  
  if len(args) < 1  {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }
  var payment map[string]string
  json.Unmarshal([]byte(args[0]), &payment)
  
  
  
  	var wallet map[string]string
  	wallet_Bytes, _ := 	APIstub.GetState(payment["paymentFrom"] )
   	if(wallet_Bytes  == nil){
      return shim.Error("Error occurred")
    }
     json.Unmarshal(wallet_Bytes, &wallet)
     balance,_  := strconv.Atoi(wallet["balance"])     
     amount,_ := strconv.Atoi(payment["amount"])
     
     if balance - amount >= 0 {
     wallet["balance"] = strconv.Itoa(balance - amount)
     
     	var cow map[string]interface{}
  		cow_Bytes, _ := APIstub.GetState(payment["cowId"] )
  	 	if cow_Bytes  == nil {
   	   return shim.Error("Error occured")
   		 }
   		 
   		  json.Unmarshal(cow_Bytes, &cow)
     var bid map[string]string
  		bid_Bytes, _ := APIstub.GetState(payment["bidId"] )
  	 	if bid_Bytes  == nil {
   	   return shim.Error("Error occurred")
   		 }
     json.Unmarshal(bid_Bytes, &bid)
     bid["status"] = "transfer"
     
     var walletAdd map[string]string
  	walletAdd_Bytes, _ := 	APIstub.GetState(cow["farmerId"].(string))
   	if(walletAdd_Bytes  == nil){
      return shim.Error("false")
    }
     json.Unmarshal(walletAdd_Bytes, &walletAdd)
     balanceAdd,_  := strconv.Atoi(walletAdd["balance"]) 
     addBalance,_ := strconv.Atoi(payment["amount"])
     balance = balanceAdd + addBalance
     walletAdd["balance"] = strconv.Itoa(balance)
        
     payment_numberBytes,_ := APIstub.GetState(PAYMENT_TXN)
        if payment_numberBytes  == nil {
      return shim.Error("Error occured")
                                        }
    payment_number, _:= strconv.Atoi((string)(payment_numberBytes))  
    payment_number = payment_number + 1
    payment_numberString := strconv.Itoa(payment_number)
    payment["paymentTo"] = cow["farmerId"].(string)
    payment["status"] = "Accepted"
    payment["type"] = "transaction"
    payment["cowBreed"] = cow["breed"].(string)
    payment["rate"] = "false"
    payment["payId"] = payment_numberString
    walletAddBytes,_:=json.Marshal(walletAdd)
    walletBytes,_:=json.Marshal(wallet)
    paymentBytes,_:=json.Marshal(payment)
    bdBytes,_:=json.Marshal(bid)
    
    APIstub.PutState(payment["paymentFrom"], walletBytes)
    APIstub.PutState(payment["bidId"], bdBytes)
    APIstub.PutState(cow["farmerId"].(string), walletAddBytes)
    APIstub.PutState(payment_numberString, paymentBytes)
    APIstub.PutState(PAYMENT_TXN, []byte(payment_numberString))

    }else {
      fmt.Println("insufficient balance")
     return shim.Success([]byte("false"))
     }
     return shim.Success([]byte("true"))
}
/*
 *This method is for marking cow on sale
 */
func (s *SmartContract) markCowOnSale(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  
  if len(args) < 2  {
    return shim.Error("Incorrect number of arguments. Expecting 2")
  }
	  var appendFields map[string]interface{}
	  json.Unmarshal([]byte(args[1]), &appendFields)
  	 var cow map[string]interface{}	
  	 cow_Bytes, _ := 	APIstub.GetState(args[0])
   	 if(cow_Bytes  == nil){
       return shim.Error("Error occured")
      }
     json.Unmarshal(cow_Bytes, &cow)
     if cow["status"] == "VERIFIED" {
       for key, value := range appendFields {
		
					cow[key] = value
				}	
		 cow["OnSale"] = "true"			  
     } else {
     return shim.Success([]byte("false"))
     }
     cowBytes,_:=json.Marshal(cow)
  	 APIstub.PutState(args[0], cowBytes)
  	 return shim.Success([]byte("true"))
}

/*
 *This method return the cows data and its farmer on the basis of filter
 */
func (s* SmartContract) filterCowsAvailableForSale(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	var query string
	if len(args) < 2 {
		return shim.Error("Arguments are missing")
	}else  {
	 query = "{\"selector\":{\"$and\":[{\"type\":{\"$eq\":\"COW\"}},{\"OnSale\":{\"$eq\":\"true\"}}]}}"
	}
	 totalData:=make( [][]map[string]string,0)
	 var cowdata []map[string]string
	 var cowdataSuggestion []map[string]string
	 var otherdataSuggestion []map[string]string	
	
	fmt.Printf("- filterCowsAvailableForSale query is:\n%s\n", query)
	
	resultsIterator, err := APIstub.GetQueryResult(query)
	if err != nil {
		return shim.Error("Error occurred")
	}
	if resultsIterator == nil {
		return shim.Error("No record found")
	}
	
		
	defer resultsIterator.Close()

	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")
	bArrayMemberAlreadyWritten := false
	cowdata = make([]map[string]string, 0)
	cowdataSuggestion = make([]map[string]string, 0)
	otherdataSuggestion = make([]map[string]string,0)
	
	for resultsIterator.HasNext() {
		
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return  shim.Error("No more record ")
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Record\":")
		var record map[string]string
		
		jsonData := queryResponse.Value
		json.Unmarshal(jsonData, &record)
		
		cow_health, _:= strconv.ParseInt(record["lastHealthCheck"], 10, 64)  
		cowUnixAge := time.Unix(cow_health, 0)
		
		var today = time.Now().Unix()
		nowTodayAge := time.Unix(today, 0)
		
		hy, hm, _:= cowUnixAge.Date()
		cy, cm, _:= nowTodayAge.Date()
		
		var elapsedMonth = cm - hm
		if cy - hy >=1 {
		record["healthFlag"] ="Red"
		} else {
		if elapsedMonth >=6  {
		record["healthFlag"] ="Yellow"
		} else if elapsedMonth <6 {
		record["healthFlag"] ="Green"
		}	
		}
		cow_dob, _:= strconv.ParseInt(record["dob"], 10, 64)  
		cowUnix := time.Unix(cow_dob, 0)
		
				
		birthYear, _, _:= cowUnix.Date()
		currentYear, _, _:= nowTodayAge.Date()
		var age = currentYear - birthYear
		fmt.Printf("- filterCowsAvailableForSale cow age is is:\n%s\n", age)
		age1, _:= strconv.Atoi(args[4]) 
		age2, _:= strconv.Atoi(args[5]) 
	    //all conditions matching
	
		if record[args[0]]== args[1] && record[args[2]]== args[3] && age1 <= age && age < age2  {		
		cowdata = append(cowdata, record)
		} else if record[args[0]]== args[1] && age1 <= age && age < age2 {
		cowdataSuggestion = append(cowdataSuggestion, record)
		} else if  record[args[0]]== args[1] {
		otherdataSuggestion = append(cowdataSuggestion, record)
		}
				
		buffer.WriteString(string(jsonData))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	if !bArrayMemberAlreadyWritten {
		buffer.WriteString("No record found")
	}
	buffer.WriteString("]")
	
	totalData = append(totalData, cowdata, cowdataSuggestion, otherdataSuggestion)
	cowByte,_ := json.Marshal(totalData)
	
	fmt.Printf("- filterCowsAvailableForSale queryResult:\n%s\n", string(cowByte))
	return shim.Success(cowByte)
}

/*
 *This method return the cows data and its farmer on the basis of filter
 */
func (s* SmartContract) getAllCowsData(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	var query string
	
	if len(args) < 2 {
		return shim.Error("Arguments are missing")
	}else if args[0] == "farmerId"{
	 query = "{\"selector\":{\"$and\":[{\"type\":{\"$eq\":\"COW\"}},{\"farmerId\":{\"$eq\":\""+args[1]+"\"}},{\"status\":{\"$ne\":\"archived\"}}]}}"
	 
	}else {
	 query = "{\"selector\":{\"$and\":[{\"type\":{\"$eq\":\"COW\"}},{\"status\":{\"$ne\":\"archived\"}},{\"$or\":[{\"tehsil\":{\"$eq\":\""+args[0]+"\"}},{\"district\":{\"$eq\":\""+args[1]+"\"}}]}]}}"	
	}
	 var cowdata []map[string]string
	
	fmt.Printf("- filterCowsAvailableForSale query is:\n%s\n", query)
	
	resultsIterator, err := APIstub.GetQueryResult(query)
	if err != nil {
		return shim.Error("Error occurred")
	}
	if resultsIterator == nil {
		return shim.Error("No record found")
	}
	
	defer resultsIterator.Close()

	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")
	bArrayMemberAlreadyWritten := false
	cowdata = make([]map[string]string, 0)
		
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return  shim.Error("No more record ")
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")
		buffer.WriteString(", \"Record\":")
		var record map[string]string
		jsonData := queryResponse.Value
		json.Unmarshal(jsonData, &record)
		cow_health, _:= strconv.ParseInt(record["lastHealthCheck"], 10, 64)  
		cowUnix := time.Unix(cow_health, 0)
		var today = time.Now().Unix()
		nowToday := time.Unix(today, 0)
		hy, hm, _:= cowUnix.Date()
		cy, cm, _:= nowToday.Date()
		var elapsedMonth = cm - hm
		if cy - hy >=1 {
		record["healthFlag"] ="Red"
		} else {
		if elapsedMonth >=6  {
		record["healthFlag"] ="Yellow"
		} else if elapsedMonth <6 {
		record["healthFlag"] ="Green"
		}
		}
		cowdata = append(cowdata, record)
	    //all conditions matching
		buffer.WriteString(string(jsonData))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	if !bArrayMemberAlreadyWritten {
		buffer.WriteString("No record found")
	}
	buffer.WriteString("]")
	cowByte,_ := json.Marshal(cowdata)
	fmt.Printf("- filterCowsAvailableForSale queryResult:\n%s\n", string(cowByte))
	return shim.Success(cowByte)
}

/*
 *This method return the cows data and its farmer on the basis of filter
 */
func (s* SmartContract) getAvgPriceForCowBreed(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	var query string
	
	if len(args) < 1 {
		return shim.Error("Arguments are missing")
	}else {
	query = "{\"selector\":{\"$and\":[{\"type\":{\"$eq\":\"transaction\"}},{\""+args[0]+"\":{\"$eq\":\""+args[1]+"\"}}]}}"
	}
	 var cowdata []map[string]string
	
	fmt.Printf("- getAvgPriceForCowBreed query is:\n%s\n", query)
	
	resultsIterator, err := APIstub.GetQueryResult(query)
	if err != nil {
		return shim.Error("Error occurred")
	}
	if resultsIterator == nil {
		return shim.Error("No record found")
	}
	
	defer resultsIterator.Close()

	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")
	bArrayMemberAlreadyWritten := false
	cowAmt := 0.0
	count := 0
	cowdata = make([]map[string]string, 0)
		
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return  shim.Error("No more record ")
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")
		buffer.WriteString(", \"Record\":")
		var record map[string]string
		jsonData := queryResponse.Value
		json.Unmarshal(jsonData, &record)
		tempAmt,_:= strconv.ParseFloat( record["amount"] ,64)
		cowAmt = cowAmt + tempAmt
		count = count +1
	
		cowdata = append(cowdata, record)
	    //all conditions matching
		buffer.WriteString(string(jsonData))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	if !bArrayMemberAlreadyWritten {
		buffer.WriteString("No record found")
	}
	buffer.WriteString("]")
	
	finalAvg:= cowAmt/(float64)(count)
	value:= fmt.Sprintf("%.2f", finalAvg)
	fmt.Printf("- getAvgPriceForCowBreed queryResult:\n%s\n", string(value))
	return shim.Success([]byte(value))
}



/*
 *This method return the all records for particular type of record
 */
func (s* SmartContract) getAllRecordType( APIstub shim.ChaincodeStubInterface , args []string) sc.Response {
	
	if len(args) < 4 {
		return shim.Error("4 args required")
	 }
	query := "{\"selector\":{\"$and\":[{\"type\":{\"$eq\":\""+args[0]+"\"}},{\""+args[1]+"\":{\"$eq\":\""+args[2]+"\"}},{\""+args[3]+"\":{\"$eq\":\""+args[4]+"\"}}]}}"		
    var bids []map[string]string
	fmt.Printf("- getAllRecordType qyery is:\n%s\n", query)
	resultsIterator, err := APIstub.GetQueryResult(query)
	if err != nil {
		return shim.Error("Error occurred")
	}
	if resultsIterator == nil {
		return shim.Error("No record found")
	}
	defer resultsIterator.Close()
	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")
	bArrayMemberAlreadyWritten := false
	bids = make([]map[string]string, 0)
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return  shim.Error("No more record ")
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Record\":")
		var record map[string]string
		jsonData := queryResponse.Value
		json.Unmarshal(jsonData, &record)
		bids = append(bids, record)
		buffer.WriteString(string(jsonData))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	if !bArrayMemberAlreadyWritten {
		buffer.WriteString("No record found")
	}
	buffer.WriteString("]")
	roByte,_ := json.Marshal(bids)
	fmt.Printf("- getAllRecordType queryResult:\n%s\n", string(roByte))
	return shim.Success(roByte)

}

/*
 *This method return the all records for particular type of record
 */
func (s* SmartContract) getAllEntities( APIstub shim.ChaincodeStubInterface , args []string) sc.Response {
	
	if len(args) < 1 {
		return shim.Error("1 args required")
	 }
    query := "{\"selector\":{\"$and\":[{\"type\":{\"$eq\":\""+args[0]+"\"}}]}}"
	
    var bids []map[string]interface{}
	fmt.Printf("- getAllEntities qyery is:\n%s\n", query)
	resultsIterator, err := APIstub.GetQueryResult(query)
	if err != nil {
		return shim.Error("Error occurred")
	}
	if resultsIterator == nil {
		return shim.Error("No record found")
	}
	defer resultsIterator.Close()
	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")
	bArrayMemberAlreadyWritten := false
	bids = make([]map[string]interface{}, 0)
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return  shim.Error("No more record ")
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Record\":")
		var record map[string]interface{}
		jsonData := queryResponse.Value
		json.Unmarshal(jsonData, &record)
		bids = append(bids, record)
		buffer.WriteString(string(jsonData))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	if !bArrayMemberAlreadyWritten {
		buffer.WriteString("No record found")
	}
	buffer.WriteString("]")
	roByte,_ := json.Marshal(bids)
	fmt.Printf("- getAllEntities queryResult:\n%s\n", string(roByte))
	return shim.Success(roByte)

}

/*
 *This method return the all FarmerBids
 */
func (s* SmartContract) getAllFarmerBids( APIstub shim.ChaincodeStubInterface , args []string) sc.Response {
	
	if len(args) < 3 {
		return shim.Error("3 args required")
	 }
	query := "{\"selector\":{\"$and\":[{\"type\":{\"$eq\":\""+args[0]+"\"}},{\""+args[1]+"\":{\"$eq\":\""+args[2]+"\"}},{\"status\":{\"$ne\":\"REJECTED\"}}]}}"		
    var bids []map[string]string
	fmt.Printf("- getAllRecordType qyery is:\n%s\n", query)
	resultsIterator, err := APIstub.GetQueryResult(query)
	if err != nil {
		return shim.Error("Error occurred")
	}
	if resultsIterator == nil {
		return shim.Error("No record found")
	}
	defer resultsIterator.Close()
	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")
	bArrayMemberAlreadyWritten := false
	bids = make([]map[string]string, 0)
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return  shim.Error("No more record ")
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Record\":")
		var record map[string]string
		jsonData := queryResponse.Value
		json.Unmarshal(jsonData, &record)
		bids = append(bids, record)
		buffer.WriteString(string(jsonData))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	if !bArrayMemberAlreadyWritten {
		buffer.WriteString("No record found")
	}
	buffer.WriteString("]")
	roByte,_ := json.Marshal(bids)
	fmt.Printf("- getAllRecordType queryResult:\n%s\n", string(roByte))
	return shim.Success(roByte)

}



/*
 *This method is for marking cow on sale
 */
func (s *SmartContract) bidForCow(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  
  if len(args) < 1  {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }
  	var bid map[string]string
  	 json.Unmarshal([]byte(args[0]), &bid)
  	 bid_numberBytes,_ := APIstub.GetState(BID_KEY)
    if bid_numberBytes  == nil {
      return shim.Error("Error occured")
    }
   bid_number, _:= strconv.Atoi((string)(bid_numberBytes))  
   bid_number = bid_number + 1
   bid_numberString := strconv.Itoa(bid_number) 
   fmt.Println("bid id is: %s", bid_number)
   bid["type"] ="bid"	
   	bidKey :="bid"+strconv.Itoa(bid_number)
  	var cow map[string]interface{}
  	cow_Bytes, _ := APIstub.GetState(bid["cowId"] )
   	if cow_Bytes  == nil {
      return shim.Error("Error occured")
    } 
     json.Unmarshal(cow_Bytes, &cow)
     fmt.Println("no of bids is: %s", cow["noOfbids"].(string))
     if cow["noOfbids"] == "S" {
     cow["bids"] = bidKey
     cow["noOfbids"] = "M"
     }else if cow["noOfbids"] =="M" {
     cow["bids"] = cow["bids"].(string) +","+ bidKey
     }
     bid["bidId"] = bidKey
     cowBytes,_:=json.Marshal(cow)
     bidBytes,_:=json.Marshal(bid)
  	 APIstub.PutState(bid["cowId"], cowBytes)
  	 APIstub.PutState(BID_KEY, []byte(bid_numberString))
  	 APIstub.PutState(bidKey, bidBytes)
  	 return shim.Success([]byte(bidKey))
}


/*
 *this method accept the requested  bid on the basis of bidId and reject all other bids for a particular cow
 */
func (s *SmartContract) acceptBid(APIstub shim.ChaincodeStubInterface, args []string) sc.Response{

 	if len(args) <1 {
 	return shim.Error("Incorrect number of arguments. Expecting 1")
 	}
 	var bid map[string]string
 	json.Unmarshal([]byte(args[0]), &bid)
 	var actualbid map[string]string
 	bid_Byte, _ := APIstub.GetState(bid["bidId"] )
 	json.Unmarshal(bid_Byte, &actualbid)
 	actualbid["status"]="ACCEPTED"
	var cow map[string]interface{}
  	cow_Bytes, _ := APIstub.GetState(bid["cowId"] )
   	if cow_Bytes  == nil {
      return shim.Error("Error occurred")
    }
     json.Unmarshal(cow_Bytes, &cow)
   var bids string =  cow["bids"].(string)
  	bidsSlice := strings.Split(bids, ",")
  	if len(bidsSlice) > 1 {
  	for _,val := range bidsSlice {
  	var abid map[string]string
  	bid_Bytes, _ := APIstub.GetState(val)
   	if bid_Bytes  == nil {
      return shim.Error("Error occured")
    }
     json.Unmarshal(bid_Bytes, &abid)
 	abid["status"]="REJECTED"
 	abid["lastModifiedBy"] =cow["farmerId"].(string)
 	 bidBytes,_:=json.Marshal(abid)
  	 APIstub.PutState(val, bidBytes)
 	
  	}
  	}
  	if cow["noOfOwner"] == "X"{
  	cow["oldOwner"] = cow["farmerId"].(string)
  	} else{
  	cow["oldOwner"]= cow["oldOwner"].(string) +","+ cow["farmerId"].(string)
  	cow["noOfOwner"] = "Y"
  	}
  	cow["farmerId"]  = bid["farmerId"]
  	cow["OnSale"] = "false"
  	cow["noOfbids"] = "S"
  	delete(cow, "bids")
   	currentbidBytes,_:=json.Marshal(actualbid)
   	 cowBytes,_:=json.Marshal(cow)
  	 APIstub.PutState(actualbid["bidId"], currentbidBytes)
  	 APIstub.PutState(actualbid["cowId"], cowBytes)
  	 return shim.Success([]byte("true"))
}

//milk related code
/*
 *This method is for adding milk stock in marketplace
 */
func (s *SmartContract) addMilk(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  
  if len(args) < 1  {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }
  	var entity map[string]string
    json.Unmarshal([]byte(args[0]), &entity)
	  milk_numberBytes,_ := APIstub.GetState(MILK_KEY)
    if milk_numberBytes  == nil {
      return shim.Error("Error occured")
    }
    var cow map[string]string
    cow_Bytes, _ := APIstub.GetState(entity["cowId"] )
   	if cow_Bytes  == nil {
      return shim.Error("Error occured")
    }
     json.Unmarshal(cow_Bytes, &cow)
   milk_number, _:= strconv.Atoi((string)(milk_numberBytes))  
    milk_number = milk_number + 1
    milk_numberString := strconv.Itoa(milk_number)
    fmt.Printf("milk id is: %s", milk_number)
	entity["milkId"] = MILK_KEY+ milk_numberString
	entity["type"] = "MILK"
	entity["noOfbids"] = "S"
	entity["breed"] = cow["breed"]
	milk,_ := json.Marshal(entity)
   	APIstub.PutState(entity["milkId"], milk)
   	APIstub.PutState(MILK_KEY, []byte(milk_numberString))
  	return shim.Success([]byte(entity["milkId"]))
}

/*
 *This method returns the milk available for sale
 */
func (s* SmartContract) getMilkAvailableForSale(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	var query string
	query = "{\"selector\":{\"$and\":[{\"type\":{\"$eq\":\"MILK\"}},{\"OnSale\":{\"$eq\":\"true\"}}]}}"
	 var milkdata []map[string]string
	fmt.Printf("- getMilkAvailableForSale query is:\n%s\n", query)
	resultsIterator, err := APIstub.GetQueryResult(query)
	if err != nil {
		return shim.Error("Error occurred")
	}
	if resultsIterator == nil {
		return shim.Error("No record found")
	}
	defer resultsIterator.Close()
	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")
	bArrayMemberAlreadyWritten := false
	milkdata = make([]map[string]string, 0)
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return  shim.Error("No more record ")
		}
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")
		buffer.WriteString(", \"Record\":")
		var record map[string]string
		jsonData := queryResponse.Value
		json.Unmarshal(jsonData, &record)
		milkdata = append(milkdata,record)
		buffer.WriteString(string(jsonData))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	if !bArrayMemberAlreadyWritten {
		buffer.WriteString("No record found")
	}
	buffer.WriteString("]")
	milkByte,_ := json.Marshal(milkdata)
	fmt.Printf("- getMilkAvailableForSale queryResult:\n%s\n", string(milkByte))
	return shim.Success(milkByte)
}

/*
 *This method is to bid for milk
 */
func (s *SmartContract) bidForMilk(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  if len(args) < 1  {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }
  fmt.Println("in bidding " + args[0])
  	var bid map[string]string
  	 json.Unmarshal([]byte(args[0]), &bid)
  	 bid_numberBytes,_ := APIstub.GetState(BID_KEY_MILK)
    if bid_numberBytes  == nil {
      return shim.Error("Error occured")
    }
   bid_number, _:= strconv.Atoi((string)(bid_numberBytes))  
   bid_number = bid_number + 1
   bid_numberString := strconv.Itoa(bid_number) 
   fmt.Println("bid id is: %s", bid_number)
   bid["type"] ="bid"	
   	bidKey :="bid"+strconv.Itoa(bid_number)
  	var milk map[string]interface{}
  	milk_Bytes, _ := APIstub.GetState(bid["milkId"] )
   	if milk_Bytes  == nil {
      return shim.Error("Error occured")
    } 
     json.Unmarshal(milk_Bytes, &milk)
     fmt.Println("no of bids is: %s", milk["noOfbids"].(string))
     if milk["noOfbids"] == "S" {
     milk["bids"] = bidKey
     milk["noOfbids"] = "M"
     }else if milk["noOfbids"] =="M" {
     milk["bids"] = milk["bids"].(string) +","+ bidKey
     }
       fmt.Println("passed till here 3")
     bid["bidId"] = bidKey
     milkBytes,_:=json.Marshal(milk)
     bidBytes,_:=json.Marshal(bid)
  	 APIstub.PutState(bid["milkId"], milkBytes)
  	 APIstub.PutState(BID_KEY_MILK, []byte(bid_numberString))
  	 APIstub.PutState(bidKey, bidBytes)
  	 return shim.Success([]byte(bidKey))
}
/*
 *this method accept the requested  bid on the basis of bidId and reject all other bids for the milkId
 */
func (s *SmartContract) acceptBidMilk(APIstub shim.ChaincodeStubInterface, args []string) sc.Response{

 	if len(args) <1 {
 	return shim.Error("Incorrect number of arguments. Expecting 1")
 	}
 	var bid map[string]string
 	json.Unmarshal([]byte(args[0]), &bid)
 	var actualbid map[string]string
 	bid_Byte, _ := APIstub.GetState(bid["bidId"])
 	json.Unmarshal(bid_Byte, &actualbid)
 	actualbid["status"]="ACCEPTED"
	var milk map[string]string
  	milk_Bytes, _ := APIstub.GetState(actualbid["milkId"] )
   	if milk_Bytes  == nil {
      return shim.Error("Error occurred")
    }
     json.Unmarshal(milk_Bytes, &milk)
   var bids string =  milk["bids"]
  	bidsSlice := strings.Split(bids, ",")
  	if len(bidsSlice) > 1 {
  	for _,val := range bidsSlice {
  	var abid map[string]string
  	bid_Bytes, _ := APIstub.GetState(val)
   	if bid_Bytes  == nil {
      return shim.Error("Error occurred")
    }
     json.Unmarshal(bid_Bytes, &abid)
 	abid["status"]="REJECTED"
 	 bidBytes,_:=json.Marshal(abid)
  	 APIstub.PutState(val, bidBytes)
  	}
  	}
  	milk["currentOwner"]  = actualbid["userId"]
  	milk["OnSale"] = "false"
  	milk["saleAmount"] = actualbid["amount"]
  	milk["time"] = bid["time"]
  	milk["status"] = "sold"
  	
   	currentbidBytes,_:=json.Marshal(actualbid)
   	milkBytes,_:=json.Marshal(milk)
  	 APIstub.PutState(actualbid["bidId"], currentbidBytes)
  	 APIstub.PutState(actualbid["milkId"], milkBytes)
  	 return shim.Success([]byte("true"))
}

/*
 *This method return wallet details
 */
func (s* SmartContract) getWalletDetails(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	var query string
	if len(args) < 1 {
		return shim.Error("Arguments are missing")
	}else {
	 query = "{\"selector\":{\"$and\":[{\"type\":{\"$eq\":\"transaction\"}},{\"$or\":[{\"paymentFrom\":{\"$eq\":\""+args[0]+"\"}},{\"paymentTo\":{\"$eq\":\""+args[0]+"\"}}]}]}}}"	
	}
	 var txns [][]map[string]string
	 var txnsAdd []map[string]string
	 var txnsSub []map[string]string
	fmt.Printf("- getWalletDetails query is:\n%s\n", query)
	resultsIterator, err := APIstub.GetQueryResult(query)
	if err != nil {
		return shim.Error("Error occurred")
	}
	if resultsIterator == nil {
		return shim.Error("No record found")
	}
	defer resultsIterator.Close()
	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")
	bArrayMemberAlreadyWritten := false
	txns = make([][]map[string]string, 0)
	txnsAdd = make([]map[string]string ,0)
	txnsSub = make([]map[string]string, 0)
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return  shim.Error("No more record ")
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")
		buffer.WriteString(", \"Record\":")
		var record map[string]string
		jsonData := queryResponse.Value
		json.Unmarshal(jsonData, &record)
		if record["paymentFrom"] == args[0] {
		txnsSub = append(txnsSub, record)
		} else if record["paymentTo"] == args[0] {
		txnsAdd = append(txnsAdd, record)
		}

		buffer.WriteString(string(jsonData))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	if !bArrayMemberAlreadyWritten {
		buffer.WriteString("No record found")
	}
	buffer.WriteString("]")
	txns = append(txns, txnsAdd, txnsSub)
	txnsByte,_ := json.Marshal(txns)
	fmt.Printf("- getWalletDetails queryResult:\n%s\n", string(txnsByte))
	return shim.Success(txnsByte)
}

/*
 *This method is for rating sellers in marketplace
 */
func (s *SmartContract) rating(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
  
  if len(args) < 1  {
    return shim.Error("Incorrect number of arguments. Expecting 1")
  }
  	var rating map[string]string
    json.Unmarshal([]byte(args[0]), &rating)
	 rate_numberBytes,_ := APIstub.GetState(RATING)
    if rate_numberBytes  == nil {
      return shim.Error("Error occurred")
    }
    
    var payment map[string]string
    pay_numberBytes,_ := APIstub.GetState(rating["payId"])
    if pay_numberBytes  == nil {
      return shim.Error("Error occurred")
    }
    json.Unmarshal(pay_numberBytes, &payment)
    payment["rate"] ="true"
    payBytes,_:=json.Marshal(payment)
    
   	rate_number, _:= strconv.Atoi((string)(rate_numberBytes))  
    rate_number = rate_number + 1
    rate_numberString := strconv.Itoa(rate_number)
	rating["ratingId"] = RATING+ rate_numberString
	rating["type"] = RATING
	var userProfile map[string]string
  	walletAdd_Bytes, _ := 	APIstub.GetState(rating["ratedTo"])
   	if(walletAdd_Bytes  == nil){
      return shim.Error("false")
    }
     json.Unmarshal(walletAdd_Bytes, &userProfile)
     if _, ok := userProfile["rating"]; ok {//  rate_numberString := strconv.Itoa(rate_number)
     	noOfRate,_:= strconv.Atoi(userProfile["ratingCount"])
     	oldRate_number, _:= strconv.ParseFloat(userProfile["rating"] ,64)
     	fmt.Println("oldRate_number ",oldRate_number)
     	simpleRating, _:= strconv.ParseFloat(rating["rating"], 64)
	    aiRating, _:= strconv.ParseFloat(rating["aiRating"], 64)
	    fmt.Println("simple rating ",simpleRating)
	     fmt.Println("ai rating ",aiRating)
	    newRate := (0.7 * simpleRating) + (0.3 * aiRating)
	     fmt.Println("newRate ",newRate)
     	var rat = (0.7 * newRate) + (0.3 * oldRate_number)
     	 fmt.Println("final ",rat)
     	userProfile["ratingCount"] =  strconv.Itoa(noOfRate+1)
     	userProfile["rating"] = fmt.Sprintf("%.2f", rat)
	  } else {
	  simpleRating, _:= strconv.ParseFloat(rating["rating"], 64)
	  aiRating, _:= strconv.ParseFloat(rating["aiRating"], 64)
	  finalRating := (0.7 * simpleRating) + (0.3 * aiRating)	  
	  userProfile["rating"] = fmt.Sprintf("%.2f", finalRating)
	  userProfile["ratingCount"] = "1"
	  }
    ratings,_ := json.Marshal(rating)
    walletBytes,_:=json.Marshal(userProfile)
   	APIstub.PutState(rating["ratingId"], ratings)
   	APIstub.PutState(RATING, []byte(rate_numberString))
   	APIstub.PutState(rating["ratedTo"], walletBytes)
   	APIstub.PutState(rating["payId"], payBytes)
  	return shim.Success([]byte(rating["ratingId"]))
}


/*
 *This method returns the gaussian distance of milk prices
 */
func (s* SmartContract) gaussianDistance(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
    var query string

    var cow map[string]string
     cow_Bytes, _ := APIstub.GetState(args[0])
   	if cow_Bytes  == nil {
      return shim.Error("Error occurred")
    }
     json.Unmarshal(cow_Bytes, &cow)
	query = "{\"selector\":{\"$and\":[{\"type\":{\"$eq\":\"MILK\"}},{\"status\":{\"$eq\":\"sold\"}},{\"district\":{\"$eq\":\""+args[1]+"\"}},{\"breed\":{\"$eq\":\""+cow["breed"]+"\"}}]}}"
	resultsIterator, err := APIstub.GetQueryResult(query)
	var saleAmount float64
	var count int
	var globalVariance float64
	var monthsaleAmount float64
	var monthcount int
	var monthlyVariance float64
	if err != nil {
		return shim.Error("Error occurred")
	}
	if resultsIterator == nil {
		return shim.Error("No record found")
	}
	defer resultsIterator.Close()
	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")
	bArrayMemberAlreadyWritten := false
	
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return  shim.Error("No more record ")
		}
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")
		buffer.WriteString(", \"Record\":")
		var record map[string]string
		jsonData := queryResponse.Value
		json.Unmarshal(jsonData, &record)
		saleAmt,_:=strconv.ParseFloat(record["saleAmount"], 64)
		quant,_:=strconv.ParseFloat(record["quantity"], 64)
		saleAmt = saleAmt/quant
		
		saleAmount= saleAmt+ saleAmount
		count = count+1
		globalVariance = globalVariance + math.Pow(saleAmt,2)
		milkTime, _:= strconv.ParseInt(record["time"], 10, 64) 
		milkUnixAge := time.Unix(milkTime, 0)
		var today = time.Now().Unix()
		nowTodayAge := time.Unix(today, 0)
		hy, hm, _:= milkUnixAge.Date()
		cy, cm, _:= nowTodayAge.Date()
		var elapsedMonth = cm - hm
		if cy - hy ==0 {
		if elapsedMonth <= 1{
		monthsaleAmount= saleAmt+ monthsaleAmount
			fmt.Println(monthsaleAmount)
		monthcount = monthcount+1
		monthlyVariance = monthlyVariance + math.Pow(saleAmt,2)
		}
		} 
		buffer.WriteString(string(jsonData))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	if !bArrayMemberAlreadyWritten {
		buffer.WriteString("No record found")
	}
	buffer.WriteString("]")
	globalMean:= saleAmount/(float64)(count)
	varGlobal:= globalVariance/(float64)(count)-  math.Pow(globalMean,2)
	
	monthlyMean:=monthsaleAmount/(float64)(monthcount)
	varMonth:= monthlyVariance/(float64)(monthcount)- math.Pow(monthlyMean,2)
	
	var finalSuggestion =  ((varMonth + math.Pow((globalMean -monthlyMean),2))/(2 * varGlobal)) - 0.5 + ((varGlobal + math.Pow((globalMean -monthlyMean),2))/(2*varMonth)) - 0.5
	return shim.Success([]byte(fmt.Sprintf("%.2f", finalSuggestion)))
}


/*
 *This method returns the Suggested Price of milk For Sale
 */
func (s* SmartContract) getMilkSuggestedPriceForSale(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
    var query string

    var cow map[string]string
     cow_Bytes, _ := APIstub.GetState(args[0])
   	if cow_Bytes  == nil {
      return shim.Error("Error occurred")
    }
     json.Unmarshal(cow_Bytes, &cow)
	query = "{\"selector\":{\"$and\":[{\"type\":{\"$eq\":\"MILK\"}},{\"status\":{\"$eq\":\"sold\"}},{\"district\":{\"$eq\":\""+args[1]+"\"}},{\"breed\":{\"$eq\":\""+cow["breed"]+"\"}}]}}"
	resultsIterator, err := APIstub.GetQueryResult(query)
	var saleAmount float64
	var count int
	var monthsaleAmount float64
	var monthcount int
	if err != nil {
		return shim.Error("Error occurred")
	}
	if resultsIterator == nil {
		return shim.Error("No record found")
	}
	defer resultsIterator.Close()
	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")
	bArrayMemberAlreadyWritten := false
	
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return  shim.Error("No more record ")
		}
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")
		buffer.WriteString(", \"Record\":")
		var record map[string]string
		jsonData := queryResponse.Value
		json.Unmarshal(jsonData, &record)
		saleAmt,_:=strconv.ParseFloat(record["saleAmount"], 64)
		quant,_:=strconv.ParseFloat(record["quantity"], 64)
		saleAmt = saleAmt/quant
		
		saleAmount= saleAmt+ saleAmount
		count = count+1
		milkTime, _:= strconv.ParseInt(record["time"], 10, 64) 
		milkUnixAge := time.Unix(milkTime, 0)
		var today = time.Now().Unix()
		nowTodayAge := time.Unix(today, 0)
		hy, hm, _:= milkUnixAge.Date()
		cy, cm, _:= nowTodayAge.Date()
		var elapsedMonth = cm - hm
		if cy - hy ==0 {
		if elapsedMonth <= 1{
		monthsaleAmount= saleAmt+ monthsaleAmount
		monthcount = monthcount+1
	
		}
		} 
		buffer.WriteString(string(jsonData))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	if !bArrayMemberAlreadyWritten {
		buffer.WriteString("No record found")
	}
	buffer.WriteString("]")
	globalMean:= saleAmount/(float64)(count)
	
	monthlyMean:=monthsaleAmount/(float64)(monthcount)
	
	var finalSuggestion =  .3 * globalMean + .7  * monthlyMean
	return shim.Success([]byte(fmt.Sprintf("%.2f", finalSuggestion)))
}

/*
 *This method returns the Suggested Price of milk For Sale
 */
func (s* SmartContract) getAvailableMilkQuantity(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
    var query string
	query = "{\"selector\":{\"$and\":[{\"type\":{\"$eq\":\"MILK\"}},{\"OnSale\":{\"$eq\":\"true\"}},{\"farmerId\":{\"$eq\":\""+args[0]+"\"}}]}}"
	resultsIterator, err := APIstub.GetQueryResult(query)
	var saleQuant float64
	if err != nil {
		return shim.Error("Error occurred")
	}
	if resultsIterator == nil {
		return shim.Error("No record found")
	}
	defer resultsIterator.Close()
	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")
	bArrayMemberAlreadyWritten := false
	
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return  shim.Error("No more record ")
		}
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")
		buffer.WriteString(", \"Record\":")
		var record map[string]string
		jsonData := queryResponse.Value
		json.Unmarshal(jsonData, &record)
		quant,_:=strconv.ParseFloat(record["quantity"], 64)
		saleQuant= quant + saleQuant
		buffer.WriteString(string(jsonData))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	if !bArrayMemberAlreadyWritten {
		buffer.WriteString("No record found")
	}
	buffer.WriteString("]")
	
	return shim.Success([]byte(fmt.Sprintf("%.2f", saleQuant)))
}

// The main function is only relevant in unit test mode. Only included here for completeness.
func main() {

  // Create a new Smart Contract
  err := shim.Start(new(SmartContract))
  if err != nil {
    fmt.Printf("Error creating new Smart Contract: %s", err)
  }
}