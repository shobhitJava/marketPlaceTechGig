package com.mp.utility.persistence;

import static com.mongodb.client.model.Filters.eq;

import org.bson.Document;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.mongodb.MongoBulkWriteException;
import com.mongodb.MongoClient;
import com.mongodb.MongoWriteException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mp.utility.models.Dairy;

@Component
public class DairyDB {

	MongoClient mongo = new MongoClient("10.64.217.120", 27017);

	public boolean saveDoctor(Dairy dairy) {

		MongoDatabase database = mongo.getDatabase("test");
		MongoCollection<Document> collection = database.getCollection("dairy");
		try {
			Document document = new Document();
			document.put("name", dairy.getName());
			document.put("mobile", dairy.getMobile());
			document.put("state", dairy.getState());
			document.put("district", dairy.getDistrict());
			document.put("dairyId", dairy.getDairyId());
			document.put("tehsil", dairy.getTehsil());

			collection.insertOne(document);

		} catch (MongoWriteException e) {
			System.out.println(e.getMessage());
			return false;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		// System.out.println("total # of documents after inserting 100 small
		// ones (should be 101) " + collection.countDocuments());
		System.out.println("done md");
		return true;

	}

	public Dairy getDoctorProfile(String dairyId) {
		Dairy user = null;
		MongoDatabase database = mongo.getDatabase("test");
		MongoCollection<Document> collection = database.getCollection("dairy");
		try {
			FindIterable<Document> doc = collection.find(eq("dairyId", dairyId));
			for (Document d : doc) {
				System.out.println(d);
				Gson s = new Gson();
				user = s.fromJson(d.toJson(), Dairy.class);

			}
		} catch (MongoBulkWriteException e) {
			System.out.println(e.getMessage());

		}
		return user;
	}
}
