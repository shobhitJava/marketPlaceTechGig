package com.mp.utility.persistence;

import static com.mongodb.client.model.Filters.eq;

import org.bson.Document;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.mongodb.MongoBulkWriteException;
import com.mongodb.MongoClient;
import com.mongodb.MongoWriteException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mp.utility.models.User;

@Component
public class UserDB {

	MongoClient mongo = new MongoClient("10.64.217.120", 27017);

	public boolean uploadUser(User user) {

		MongoDatabase database = mongo.getDatabase("test");
		MongoCollection<Document> collection = database.getCollection("farmers");
		try {
			Document document = new Document();
			document.put("name", user.getName());
			document.put("aadharId", user.getAadharId());
			document.put("mobile", user.getMobile());
			document.put("state", user.getState());
			document.put("district", user.getDistrict());
			document.put("dob", user.getDob());
			document.put("gender", user.getGender());
			document.put("farmerId", user.getfarmerId());
			document.put("tehsil", user.getTehsil());
			document.put("publicKey", user.getPublicKey());

			collection.insertOne(document);

		} catch (MongoWriteException e) {
			System.out.println(e.getMessage());
			return false;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		// System.out.println("total # of documents after inserting 100 small
		// ones (should be 101) " + collection.countDocuments());
		System.out.println("done md");
		return true;

	}

	public User getFarmerProfile(String farmerId) {
		User user = null;
		MongoDatabase database = mongo.getDatabase("test");
		MongoCollection<Document> collection = database.getCollection("farmers");
		try {
			FindIterable<Document> doc = collection.find(eq("farmerId", farmerId));
			System.out.println("here1"+doc);
			for (Document d : doc) {
				System.out.println(d);
				Gson s = new Gson();
				user = s.fromJson(d.toJson(), User.class);

			}
		} catch (MongoBulkWriteException e) {
			System.out.println(e.getMessage());

		}
		return user;
	}

}
