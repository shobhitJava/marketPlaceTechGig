package com.mp.utility.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class HealthRecord {

	private String doctorId;
	private String checkUpTime;
	private String healthCertificate;
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public String getCheckUpTime() {
		return checkUpTime;
	}
	public void setCheckUpTime(String checkUpTime) {
		this.checkUpTime = checkUpTime;
	}
	public String getHealthCertificate() {
		return healthCertificate;
	}
	public void setHealthCertificate(String healthCertificate) {
		this.healthCertificate = healthCertificate;
	}
	
	}
