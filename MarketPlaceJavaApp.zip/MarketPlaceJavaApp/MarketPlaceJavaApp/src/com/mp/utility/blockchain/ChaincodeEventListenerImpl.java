package com.mp.utility.blockchain;

import org.hyperledger.fabric.sdk.BlockEvent;
import org.hyperledger.fabric.sdk.ChaincodeEvent;
import org.hyperledger.fabric.sdk.ChaincodeEventListener;

public class ChaincodeEventListenerImpl implements ChaincodeEventListener {

	@Override
	public void received(String handle, BlockEvent blockEvent, ChaincodeEvent chaincodeEvent) {

		String es = blockEvent.getPeer() != null ? blockEvent.getPeer().getName() : blockEvent.getEventHub().getName();
		System.out.println(" +++++++++++++++++++++++++RECEIVED Chaincode event with handle: %s, chaincode Id: %s, chaincode event name: %s, "
				+ "transaction id: %s, event payload: \"%s\", from eventhub: %s"+handle+
				chaincodeEvent.getChaincodeId()+ chaincodeEvent.getEventName()+chaincodeEvent.getTxId()+
				new String(chaincodeEvent.getPayload())+ es);

	}

}
