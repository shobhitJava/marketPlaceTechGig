package com.mp.utility.keypair;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

public class GenerateKeys {

    private KeyPairGenerator keyGen;
    private KeyPair pair;
    private PrivateKey privateKey;
    private PublicKey publicKey;

    public GenerateKeys(int keylength)  {

        try {
			this.keyGen = KeyPairGenerator.getInstance("DSA");
			 this.keyGen.initialize(keylength);
		} catch (NoSuchAlgorithmException e) {
			System.out.println(e.getMessage());
		}
       
    }

    public void createKeys() {
        this.pair = this.keyGen.generateKeyPair();
        this.privateKey = pair.getPrivate();
        this.publicKey = pair.getPublic();

    }

    public PrivateKey getPrivateKey() {
        return this.privateKey;
    }

    public PublicKey getPublicKey() {
        return this.publicKey;
    }

    public void writeToFile(String path, byte[] key) throws IOException {

        File f = new File(path);
        f.getParentFile().mkdirs();

        FileOutputStream fos = new FileOutputStream(f);
        fos.write(key);
        fos.flush();
        fos.close();

    }

    public  String generateKeys(GenerateKeys myKeys) {
         myKeys.createKeys();
     
         return new String(myKeys.getPrivateKey().getEncoded());
         /*
              FileWriter fw=new FileWriter("MyKeys/demo.pem"); 
              PemWriter writer = new PemWriter(fw); 
                  writer.writeObject(new PemObject("CERTIFICATE", myKeys.getPublicKey().getEncoded()));  
                  writer.close();
               FileWriter fw2=new FileWriter("MyKeys/demo_sk"); 
              PemWriter writer2 = new PemWriter(fw2);
                    writer2.writeObject(new PemObject("Private Key", myKeys.getPrivateKey().getEncoded()));
                   
                    writer2.close();*/

         
    }
}