package com.mp.utility.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mp.utility.models.Dairy;
import com.mp.utility.services.DairyDataService;

@Controller
@RequestMapping("/api/dairy")
//To DO
//to create api method specific for doctor
public class DairyController {

	@Autowired
	private DairyDataService dairyDataService;

	@RequestMapping(value = "/registerProfile", method = RequestMethod.POST)
	@ResponseBody
	public String saveUser(@RequestBody Dairy dairy ) {
		
		return dairyDataService.saveDairyProfile(dairy);
	}

	@RequestMapping(value = "/getDairyProfile/{dairyId}", method = RequestMethod.GET)
	@ResponseBody
	public Dairy getDairyProfile(@PathVariable("dairyId") String dairyId) {
			
		return dairyDataService.getDairyProfile(dairyId);
	
	}

	@RequestMapping(value = "/rating", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean rating(@RequestBody String json) {
		boolean res = false;
		if (dairyDataService.rate(json)) {
			res = true;
		}
		return res;

	}
	

	
		
}
