package com.mp.utility.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mp.utility.keypair.GenerateKeys;
import com.mp.utility.models.User;
import com.mp.utility.models.UserResponse;
import com.mp.utility.services.UserDataService;

@Controller
@RequestMapping("/api/farmer")

public class FarmerController {

	@Autowired
	private UserDataService userdataService;

	@RequestMapping(value = "/registerProfile", method = RequestMethod.POST)
	@ResponseBody
	public UserResponse saveUser(@RequestBody User user) {
		UserResponse res = null;
		GenerateKeys key = new GenerateKeys(1024);
		String privKey = key.generateKeys(key);
		user.setPublicKey(new String(key.getPublicKey().getEncoded()));
		if (userdataService.saveFarmerProfile(user)) {
			res = new UserResponse();
			res.setKey(privKey);
			res.setFarmerId(user.getfarmerId());

		}
		return res;

	}

	@RequestMapping(value = "/getFarmerProfile/{farmerId}", method = RequestMethod.GET)
	@ResponseBody
	public User getFarmerProfile(@PathVariable("farmerId") String farmerId) {

		return userdataService.getFarmerProfile(farmerId);

	}

	@RequestMapping(value = "/addCow", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean addCow(@RequestBody String json) {
		boolean res = false;
		System.out.println(json);

		if (userdataService.addCow(json)) {
			res = true;
		}
		return res;

	}

	@RequestMapping(value = "/updateCow", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean updateCow(@RequestBody String json) {
		boolean res = false;
		System.out.println(json);

		if (userdataService.updateCow(json)) {
			res = true;
		}
		return res;

	}

	@RequestMapping(value = "/markCowOnSale/{cowid}", method = RequestMethod.POST)
	@ResponseBody
	public boolean markCowOnSale(@PathVariable("cowid") String cowid, @RequestBody String json) {
		boolean res = false;
		System.out.println(cowid);
		if (userdataService.markCowOnSale(cowid, json)) {
			res = true;
		}
		return res;

	}

	@RequestMapping(value = "/getAllCow/{farmerId}", method = RequestMethod.GET)
	@ResponseBody
	public String getAllCow(@PathVariable("farmerId") String farmerId) {

		return userdataService.getAllCow(farmerId);

	}
	
	@RequestMapping(value = "/auctionMilk", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean auctionMilk(@RequestBody String json) {
		boolean res = false;
		if (userdataService.auctionMilk(json)) {
			res = true;
		}
		return res;

	}
	
	@RequestMapping(value = "/acceptBidForMilk", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean acceptBidForMilk(@RequestBody String json) {
		boolean res = false;
		if (userdataService.acceptBidForMilk(json)) {
			res = true;
		}
		return res;

	}
	
	@RequestMapping(value = "/payment", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean payment(@RequestBody String json) {
		boolean res = false;
		if (userdataService.payment(json)) {
			res = true;
		}
		return res;

	}
	
	@RequestMapping(value = "/rating", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean rating(@RequestBody String json) {
		boolean res = false;
		if (userdataService.payment(json)) {
			res = true;
		}
		return res;

	}

}
