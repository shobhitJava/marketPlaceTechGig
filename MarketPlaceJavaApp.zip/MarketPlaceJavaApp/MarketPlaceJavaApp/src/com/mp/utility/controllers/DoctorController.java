package com.mp.utility.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mp.utility.models.Doctor;
import com.mp.utility.services.DocDataService;

@Controller
@RequestMapping("/api/doctor")
//To DO
//to create api method specific for doctor
public class DoctorController {

	@Autowired
	private DocDataService docDataService;

	@RequestMapping(value = "/registerProfile", method = RequestMethod.POST)
	@ResponseBody
	public String saveUser(@RequestBody Doctor doctor ) {
		
		return docDataService.saveDoctorProfile(doctor);
	}

	@RequestMapping(value = "/getDoctorProfile/{doctorId}", method = RequestMethod.GET)
	@ResponseBody
	public Doctor getFarmerProfile(@PathVariable("doctorId") String doctorId) {
			
		return docDataService.getDoctorProfile(doctorId);
	
	}

		
	@RequestMapping(value = "/updateCow/{cowId}", method = RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean updateCow (@PathVariable("cowId") String cowId,@RequestBody String json ) {
		boolean res = false;
		System.out.println(json);
			
		if (docDataService.updateCow(cowId,json)) {
			res = true;
		}
		return res;

	}
	
	@RequestMapping(value = "/getAllCow/{tehsil}/{district}", method = RequestMethod.GET)
	@ResponseBody
	public String getAllCow(@PathVariable("tehsil") String tehsil,@PathVariable("district") String district) {

		return docDataService.getAllCow(tehsil,district);

	}
	
		
}
