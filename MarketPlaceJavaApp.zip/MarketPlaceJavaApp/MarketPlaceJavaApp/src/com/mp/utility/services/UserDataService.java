package com.mp.utility.services;

import com.mp.utility.models.SearchFilter;
import com.mp.utility.models.User;

public interface UserDataService {
	
	 boolean saveFarmerProfile(User user);
	 boolean addCow(String cow);
	 boolean updateCow(String cow);
	 boolean markCowOnSale(String cowId, String json);
	 boolean bidForCow(String bid);
	 User getFarmerProfile(String farmerId);
	 String getAllCow(String farmerId);
	 String getCowsInAuction(SearchFilter json);
	 boolean auctionMilk(String milk);
	 boolean acceptBidForMilk(String bid);
	 boolean payment(String json);
	 boolean rate(String json);
	 
}
