package com.mp.utility.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mp.utility.blockchain.SDKClientMPCommonD1;

@Service
public class AuctionServiceImpl implements AuctionDataService {

	@Autowired
	SDKClientMPCommonD1 sdkClientMPCommonD1;
	String invoke = "invoke";

	@Override
	public String getAllMilk() {
		String res = sdkClientMPCommonD1.create("getMilkAvailableForSale", "query");
		return res;
	}

	@Override
	public boolean bidForMilk(String bid) {
		String res = sdkClientMPCommonD1.create("bidForMilk", invoke, bid);
		return res.startsWith("bid") ? true : false;
	}
}
