package com.mp.utility.services;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mp.utility.blockchain.SDKClientMPDoc;
import com.mp.utility.blockchain.SDKClientMPDocPair;
import com.mp.utility.models.Doctor;
import com.mp.utility.persistence.DoctorDB;

@Service
public class DoctorServiceImpl implements DocDataService {

	@Autowired
	SDKClientMPDocPair sdkClientMPDocPair;

	@Autowired
	SDKClientMPDoc sdkClientMPDoc;

	@Autowired
	DoctorDB doctorDB;

	String invoke = "invoke";


	@Override
	public String saveDoctorProfile(Doctor doctor) {
		String res ="";
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			byte[] messageDigest = md.digest(doctor.getAadharId().getBytes());
			BigInteger no = new BigInteger(1, messageDigest);
			String id = no.toString(16);
			
			doctor.setDoctorId(res);
			if(doctorDB.saveDoctor(doctor))
					res= id;
					
		} catch (NoSuchAlgorithmException e) {
			res="";
		}
		return res;
	}

	@Override
	public Doctor getDoctorProfile(String doctorId) {
		return doctorDB.getDoctorProfile(doctorId);
	}

	@Override
	public boolean updateCow(String cowId,String json) {
		String arg[] = {cowId,json};
		String res = sdkClientMPDocPair.create("updateCowHealth",invoke,arg );
		System.out.println(res);
		return res.equalsIgnoreCase("Success") ? true : false;
	}

	@Override
	public String getAllCow(String tehsil, String district) {
		String res = sdkClientMPDocPair.create("getAllCowsData", "query", tehsil, district);
		return res;
	}

}
