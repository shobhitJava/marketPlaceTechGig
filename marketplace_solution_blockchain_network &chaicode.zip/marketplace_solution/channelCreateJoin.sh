#Run mch docker-compose
#docker-compose -f docker-compose.yaml up -d



#Create commonchannel for all peers
docker exec -e "CORE_PEER_LOCALMSPID=governmentMSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@gov.test/msp/" peer0.government.test peer channel create -o orderer.mp.test:7050 -c commonchannel -f /etc/hyperledger/configtx/channel1.tx

#Create pair channel for docs and gov
docker exec -e "CORE_PEER_LOCALMSPID=governmentMSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@gov.test/msp/" peer0.government.test peer channel create -o orderer.mp.test:7050 -c pairchannel -f /etc/hyperledger/configtx/channel2.tx


#Create single channel for gov
docker exec -e "CORE_PEER_LOCALMSPID=governmentMSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@gov.test/msp/" peer0.government.test peer channel create -o orderer.mp.test:7050 -c singlechannel -f /etc/hyperledger/configtx/channel3.tx



#Join commonchannel by all  peers
docker exec -e "CORE_PEER_LOCALMSPID=governmentMSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@gov.test/msp/"  peer0.government.test peer channel join -b commonchannel.block

docker exec -e "CORE_PEER_LOCALMSPID=doctorsMSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@medical.test/msp/"  peer0.docs.test peer channel join -b commonchannel.block




docker exec -e "CORE_PEER_LOCALMSPID=dairy1MSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@firm1.test/msp/"  peer0.firm1.test peer channel join -b commonchannel.block

docker exec -e "CORE_PEER_LOCALMSPID=dairy2MSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@firm2.test/msp/"  peer0.firm2.test peer channel join -b commonchannel.block
docker exec -e "CORE_PEER_LOCALMSPID=dairy3MSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@firm3.test/msp/"  peer0.firm3.test peer channel join -b commonchannel.block
docker exec -e "CORE_PEER_LOCALMSPID=dairy4MSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@firm4.test/msp/"  peer0.firm4.test peer channel join -b commonchannel.block
docker exec -e "CORE_PEER_LOCALMSPID=dairy5MSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@firm5.test/msp/"  peer0.firm5.test peer channel join -b commonchannel.block
docker exec -e "CORE_PEER_LOCALMSPID=dairy6MSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@firm6.test/msp/"  peer0.firm6.test peer channel join -b commonchannel.block


#Join pairchannel by  docs/gov
docker exec -e "CORE_PEER_LOCALMSPID=governmentMSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@gov.test/msp/"  peer0.government.test peer channel join -b pairchannel.block


docker exec -e "CORE_PEER_LOCALMSPID=doctorsMSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@medical.test/msp/"  peer0.docs.test peer channel join -b pairchannel.block

#Join singkechannel by  gov
docker exec -e "CORE_PEER_LOCALMSPID=governmentMSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@gov.test/msp/"  peer0.government.test peer channel join -b singlechannel.block





