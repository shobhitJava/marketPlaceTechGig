package org.hyperledger.fabric.mp;

import static java.lang.String.format;
import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hyperledger.fabric.sdk.ChaincodeEndorsementPolicy;
import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.HFClient;
import org.hyperledger.fabric.sdk.InstallProposalRequest;
import org.hyperledger.fabric.sdk.InstantiateProposalRequest;
import org.hyperledger.fabric.sdk.Orderer;
import org.hyperledger.fabric.sdk.Peer;
import org.hyperledger.fabric.sdk.ProposalResponse;
import org.hyperledger.fabric.sdk.TransactionRequest.Type;
import org.hyperledger.fabric.sdk.exception.ChaincodeCollectionConfigurationException;
import org.hyperledger.fabric.sdk.exception.ChaincodeEndorsementPolicyParseException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.hyperledger.fabric.sdkintegration.Util;

public class SDKClientMP {

	private static final String CHANNEL_NAME = "singlechannel";
	static HFClient hfclient = null;
	private static final String USER_NAME = "admin";
	private static final String USER_MSP_ID = "governmentMSP";
	//private static final String USER_MSP_ID = "UserMSP";
	
	private static final String CHAIN_CODE_FILEPATH = "sdkintegration/gocc/sample1";
	private static final String CHAIN_CODE_NAME = "test6";
	private static final String CHAIN_CODE_PATH = "github.com/gov";
	private static final String CHAIN_CODE_VERSION = "1";
	private static final String TEST_FIXTURES_PATH = "src/test/fixture";
	private static final String PEER1_ADDRESS = "grpc://10.64.217.120:7060";
	private static final String PEER1_NAME = "peer0.government.test";
	private static final String ORDERER1_NAME = "orderer.mp.test";
	private static final String ORDERER1_ADDRESS = "grpc://10.64.217.120:7050";
	private static final String keystoreLocation =  "C:\\BlockchainCerti\\120\\mp";
	private static final String usercertfile = "C:\\BlockchainCerti\\120\\mp\\Admin@gov.test-cert.pem";
	private static final String orgName = "gov.test";
	
	
	public static void main(String[] args) {
		

		try {
			System.out.println("initialize logger");
			Logger logger = Logger.getLogger(SDKClientMP.class);
			logger.setLevel(Level.ERROR);
			System.out.println("creating hf client");
			File sampleStoreFile = new File(System.getProperty("user.home") + "/test.properties");

			if (sampleStoreFile.exists()) { // For testing start fresh
				sampleStoreFile.delete();
			}
			logger.info("creating store object");
			final SDKStore sdkStore = new SDKStore(sampleStoreFile);


			logger.info("creating sdk user object");
			SDKUser someTestUSER = sdkStore.getMember(USER_NAME, orgName, USER_MSP_ID,
					findFileSk(keystoreLocation), new File(usercertfile));
			
			someTestUSER.setMspId(USER_MSP_ID);
		
		
			hfclient = HFClient.createNewInstance();
		
			hfclient.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());
			hfclient.setUserContext(someTestUSER);
			
			logger.info("creating sdk user object");
			
			Channel testChannel = hfclient.newChannel(CHANNEL_NAME);
			System.out.println("joining channel");
			Peer peer1 = hfclient.newPeer(PEER1_NAME, PEER1_ADDRESS);
			Orderer orderer = hfclient.newOrderer(ORDERER1_NAME, ORDERER1_ADDRESS);
			System.out.println("adding peer "+PEER1_NAME);
			testChannel.addPeer(peer1);
	System.out.println("adding orderer "+ORDERER1_NAME);
			testChannel.addOrderer(orderer);
	
	
			testChannel.initialize();
			logger.info("Channel intialized successfully");
			
		createChainCodeGo(testChannel);
		instantiateChaincode(testChannel);
	
		}catch (Exception e) {
			System.out.println(e);
		}
	}

	
	
		public static void createChainCodeGo (Channel testChannel)
			throws InvalidArgumentException, ProposalException, IOException {
		InstallProposalRequest installProposalRequest = hfclient.newInstallProposalRequest();

		installProposalRequest.setChaincodeLanguage(Type.GO_LANG);
		installProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);

		
		installProposalRequest.setChaincodeName(CHAIN_CODE_NAME);

		
		installProposalRequest.setChaincodePath("github.com/gov");
	
		installProposalRequest.setChaincodeInputStream(Util.generateTarGzInputStream(
				(Paths.get(TEST_FIXTURES_PATH, CHAIN_CODE_FILEPATH, "src", CHAIN_CODE_PATH).toFile()),
				Paths.get("src", CHAIN_CODE_PATH).toString()));
		
		Collection<ProposalResponse> proposalResponse = testChannel.sendInstallProposal(installProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}
	}

	

	public static void instantiateChaincode(Channel testChannel)
			throws InvalidArgumentException, ProposalException, ChaincodeEndorsementPolicyParseException, IOException,
			InterruptedException, ExecutionException, TimeoutException, ChaincodeCollectionConfigurationException {
			InstantiateProposalRequest instantiateProposalRequest = hfclient.newInstantiationProposalRequest();
		instantiateProposalRequest.setChaincodeName(CHAIN_CODE_NAME);
		instantiateProposalRequest.setChaincodePath("github.com/gov");
		instantiateProposalRequest.setArgs("A", "100", "B", "200");
		instantiateProposalRequest.setChaincodeLanguage(Type.GO_LANG);
		instantiateProposalRequest.setChaincodeVersion(CHAIN_CODE_VERSION);
		Map<String, byte[]> tm = new HashMap<>();
		tm.put("HyperLedgerFabric", "InstantiateProposalRequest:JavaSDK".getBytes(UTF_8));
		tm.put("method", "InstantiateProposalRequest".getBytes(UTF_8));
		instantiateProposalRequest.setTransientMap(tm);
		instantiateProposalRequest.setProposalWaitTime(TestConfig.getConfig().getProposalWaitTime());
		instantiateProposalRequest.setTransientMap(tm);
		ChaincodeEndorsementPolicy chaincodeEndorsementPolicy = new ChaincodeEndorsementPolicy();
		chaincodeEndorsementPolicy
				.fromYamlFile(new File(TEST_FIXTURES_PATH + "/sdkintegration/mpsc.yaml"));
		instantiateProposalRequest.setChaincodeEndorsementPolicy(chaincodeEndorsementPolicy);
		//instantiateProposalRequest.setChaincodeCollectionConfiguration(ChaincodeCollectionConfiguration.fromYamlFile(new File("src/test/fixture/collectionProperties/tf.yaml")));
	
		Collection<ProposalResponse> proposalResponse = testChannel
				.sendInstantiationProposal(instantiateProposalRequest);

		Iterator<ProposalResponse> iterator = proposalResponse.iterator();

		while (iterator.hasNext()) {
			ProposalResponse proposalResponse2 = iterator.next();
			System.out.println(new String(proposalResponse2.getPayloadBytes().toByteArray()));
			System.out.println(proposalResponse2.getMessage());
			System.out.println(proposalResponse2.getChaincodeID());
			System.out.println(proposalResponse2.getPayloadBytes());

		}


		testChannel.sendTransaction(proposalResponse, hfclient.getUserContext());
		
			
	}
	
	static File findFileSk(String directorys) {

		File directory = new File(directorys);

		File[] matches = directory.listFiles((dir, name) -> name.endsWith("_sk"));

		if (null == matches) {
			throw new RuntimeException(
					format("Matches returned null does %s directory exist?", directory.getAbsoluteFile().getName()));
		}

		if (matches.length != 1) {
			throw new RuntimeException(format("Expected in %s only 1 sk file but found %d",
					directory.getAbsoluteFile().getName(), matches.length));
		}

		return matches[0];

	}

}